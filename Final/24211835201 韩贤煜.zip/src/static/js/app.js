const currency = new Intl.NumberFormat("zh-CN", { style: "currency", currency: "CNY" });
const numberFmt = new Intl.NumberFormat("zh-CN");

let currentUser = null;
let productCache = [];
let supplierCache = [];

function hasPermission(permission) {
  return Boolean(currentUser?.permissions?.includes(permission));
}

async function api(url, options = {}) {
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const data = await response.json();
  if (!response.ok) {
    if (response.status === 401) showAuth();
    throw new Error(data.message || "请求失败");
  }
  return data;
}

function toast(message) {
  const el = document.getElementById("appToast");
  el.querySelector(".toast-body").textContent = message;
  bootstrap.Toast.getOrCreateInstance(el).show();
}

function showOperationError(action, error) {
  toast(`${action}失败: ${error.message || "未知错误"}`);
}

function showLoginError(message) {
  const errorBox = document.getElementById("loginError");
  errorBox.textContent = message;
  errorBox.classList.remove("d-none");
  document.getElementById("loginUsername").classList.add("is-invalid");
  document.getElementById("loginPassword").classList.add("is-invalid");
}

function clearLoginError() {
  const errorBox = document.getElementById("loginError");
  errorBox.textContent = "";
  errorBox.classList.add("d-none");
  document.getElementById("loginUsername").classList.remove("is-invalid");
  document.getElementById("loginPassword").classList.remove("is-invalid");
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function renderInlineMarkdown(text) {
  return escapeHtml(text)
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\*([^*]+)\*/g, "<em>$1</em>")
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
}

function splitMarkdownTableRow(line) {
  const row = line.trim().replace(/^\|/, "").replace(/\|$/, "");
  const cells = [];
  let cell = "";
  let escaped = false;

  for (const char of row) {
    if (escaped) {
      cell += char;
      escaped = false;
      continue;
    }
    if (char === "\\") {
      escaped = true;
      continue;
    }
    if (char === "|") {
      cells.push(cell.trim());
      cell = "";
      continue;
    }
    cell += char;
  }
  cells.push(cell.trim());
  return cells;
}

function isMarkdownTableSeparator(line) {
  const cells = splitMarkdownTableRow(line);
  return cells.length > 0 && cells.every((cell) => /^:?-{3,}:?$/.test(cell));
}

function isMarkdownTableRow(line) {
  return line.trim().includes("|") && !isMarkdownTableSeparator(line);
}

function renderMarkdown(text) {
  const lines = String(text || "").replace(/\r\n/g, "\n").split("\n");
  const html = [];
  let inCode = false;
  let codeLines = [];
  let listType = null;

  function closeList() {
    if (listType) {
      html.push(`</${listType}>`);
      listType = null;
    }
  }

  function closeCode() {
    if (inCode) {
      html.push(`<pre><code>${escapeHtml(codeLines.join("\n"))}</code></pre>`);
      codeLines = [];
      inCode = false;
    }
  }

  for (let index = 0; index < lines.length; index += 1) {
    const rawLine = lines[index];
    const line = rawLine.trimEnd();
    const trimmed = line.trim();

    if (trimmed.startsWith("```")) {
      if (inCode) closeCode();
      else {
        closeList();
        inCode = true;
        codeLines = [];
      }
      continue;
    }

    if (inCode) {
      codeLines.push(rawLine);
      continue;
    }

    if (!trimmed) {
      closeList();
      continue;
    }

    const nextLine = lines[index + 1]?.trim() || "";
    const isTableHeader = isMarkdownTableRow(trimmed) && isMarkdownTableSeparator(nextLine);
    if (isTableHeader) {
      closeList();
      const headerCells = splitMarkdownTableRow(trimmed);
      index += 2;
      const bodyRows = [];
      while (index < lines.length && isMarkdownTableRow(lines[index])) {
        bodyRows.push(splitMarkdownTableRow(lines[index]));
        index += 1;
      }
      index -= 1;
      html.push(`
        <div class="markdown-table-wrap">
          <table class="table table-sm markdown-table">
            <thead><tr>${headerCells.map((cell) => `<th>${renderInlineMarkdown(cell)}</th>`).join("")}</tr></thead>
            <tbody>${bodyRows.map((row) => `<tr>${headerCells.map((_, cellIndex) => `<td>${renderInlineMarkdown(row[cellIndex] || "")}</td>`).join("")}</tr>`).join("")}</tbody>
          </table>
        </div>
      `);
      continue;
    }

    const heading = trimmed.match(/^(#{1,4})\s+(.+)$/);
    if (heading) {
      closeList();
      const level = heading[1].length + 2;
      html.push(`<h${level}>${renderInlineMarkdown(heading[2])}</h${level}>`);
      continue;
    }

    const unordered = trimmed.match(/^[-*]\s+(.+)$/);
    if (unordered) {
      if (listType !== "ul") {
        closeList();
        listType = "ul";
        html.push("<ul>");
      }
      html.push(`<li>${renderInlineMarkdown(unordered[1])}</li>`);
      continue;
    }

    const ordered = trimmed.match(/^\d+\.\s+(.+)$/);
    if (ordered) {
      if (listType !== "ol") {
        closeList();
        listType = "ol";
        html.push("<ol>");
      }
      html.push(`<li>${renderInlineMarkdown(ordered[1])}</li>`);
      continue;
    }

    closeList();
    html.push(`<p>${renderInlineMarkdown(trimmed)}</p>`);
  }

  closeCode();
  closeList();
  return html.join("");
}

function renderTable(id, columns, rows, actions) {
  const table = document.getElementById(id);
  if (!table) return;
  const head = columns.map((col) => `<th>${col.label}</th>`).join("");
  const body = rows.map((row) => {
    const cells = columns.map((col) => `<td>${col.render ? col.render(row) : row[col.key] ?? ""}</td>`).join("");
    const actionCell = actions ? `<td class="text-nowrap">${actions(row)}</td>` : "";
    return `<tr>${cells}${actionCell}</tr>`;
  }).join("");
  table.innerHTML = `
    <thead><tr>${head}${actions ? "<th>操作</th>" : ""}</tr></thead>
    <tbody>${body || `<tr><td colspan="${columns.length + (actions ? 1 : 0)}" class="text-center text-secondary">暂无数据</td></tr>`}</tbody>
  `;
}

function optionHtml(rows, labelKey = "name") {
  return rows.map((row) => `<option value="${row.id}">${row[labelKey]}</option>`).join("");
}

function showAuth() {
  currentUser = null;
  document.getElementById("authView").classList.remove("d-none");
  document.getElementById("appView").classList.add("d-none");
  document.getElementById("userBar").classList.add("d-none");
  document.getElementById("userBar").classList.remove("d-flex");
}

async function showApp(user) {
  currentUser = user;
  document.getElementById("authView").classList.add("d-none");
  document.getElementById("appView").classList.remove("d-none");
  document.getElementById("userBar").classList.remove("d-none");
  document.getElementById("userBar").classList.add("d-flex");
  document.getElementById("currentUsername").textContent = user.username;
  document.getElementById("roleBadge").textContent = user.role_label;
  applyPermissions();
  await refreshAll();
}

function applyPermissions() {
  document.querySelectorAll("[data-permission]").forEach((el) => {
    const ok = hasPermission(el.dataset.permission);
    el.classList.toggle("d-none", !ok);
  });

  const firstVisibleTab = document.querySelector("#mainTabs .nav-item:not(.d-none) .nav-link");
  const activeTab = document.querySelector("#mainTabs .nav-link.active");
  if (firstVisibleTab && (!activeTab || activeTab.closest(".nav-item").classList.contains("d-none"))) {
    bootstrap.Tab.getOrCreateInstance(firstVisibleTab).show();
  }
}

async function loadDashboard() {
  const data = await api("/api/dashboard");
  const cards = [
    ["商品档案", data.cards.product_count, "种"],
    ["合作供应商", data.cards.supplier_count, "家"],
    ["入库记录", data.cards.inbound_count, "单"],
    ["出库记录", data.cards.outbound_count, "单"],
    ["库存预警", data.cards.warning_count, "项"],
    ["库存资产", currency.format(data.cards.stock_amount || 0), ""],
  ];
  document.getElementById("dashboardCards").innerHTML = cards.map(([title, value, unit]) => `
    <div class="col-6 col-lg-2">
      <div class="metric"><span>${title}</span><strong>${value}${unit}</strong></div>
    </div>
  `).join("");
}

async function loadSuppliers() {
  if (!hasPermission("view_suppliers")) return;
  const keyword = document.getElementById("supplierKeyword")?.value || "";
  supplierCache = await api(`/api/suppliers?keyword=${encodeURIComponent(keyword)}`);
  renderTable("suppliersTable", [
    { key: "name", label: "供应商名称" },
    { key: "contact", label: "联系人" },
    { key: "phone", label: "电话" },
    { key: "address", label: "地址" },
    { key: "product_count", label: "关联商品" },
  ], supplierCache, hasPermission("manage_suppliers") ? (row) => `
    <button class="btn btn-sm btn-outline-primary" onclick='editSupplier(${JSON.stringify(row)})'>编辑</button>
    <button class="btn btn-sm btn-outline-danger" onclick="deleteSupplier(${row.id})">删除</button>
  ` : null);

  ["productSupplier", "inboundSupplier"].forEach((id) => {
    const select = document.getElementById(id);
    if (select) select.innerHTML = `<option value="">请选择</option>${optionHtml(supplierCache)}`;
  });
}

async function loadProducts() {
  if (!hasPermission("view_products")) return;
  const keyword = document.getElementById("productKeyword")?.value || "";
  productCache = await api(`/api/products?keyword=${encodeURIComponent(keyword)}`);
  renderTable("productsTable", [
    { key: "sku", label: "编号" },
    { key: "name", label: "名称" },
    { key: "category", label: "类别" },
    { key: "unit", label: "单位" },
    { key: "price", label: "单价", render: (row) => currency.format(row.price) },
    { key: "warning_stock", label: "预警值" },
    { key: "supplier_name", label: "供应商" },
  ], productCache, hasPermission("manage_products") ? (row) => `
    <button class="btn btn-sm btn-outline-primary" onclick='editProduct(${JSON.stringify(row)})'>编辑</button>
    <button class="btn btn-sm btn-outline-danger" onclick="deleteProduct(${row.id})">删除</button>
  ` : null);

  ["outboundProduct"].forEach((id) => {
    const select = document.getElementById(id);
    if (select) select.innerHTML = optionHtml(productCache);
  });
  const inboundSel = document.getElementById("inboundProduct");
  if (inboundSel) filterInboundProducts();
  syncProductPrice("outboundProduct", "outboundPrice");
}

function filterInboundProducts() {
  const supplierSelect = document.getElementById("inboundSupplier");
  const productSelect = document.getElementById("inboundProduct");
  if (!supplierSelect || !productSelect) {
    console.warn("filterInboundProducts: elements not found");
    return;
  }
  const supplierId = supplierSelect.value;
  console.log("filterInboundProducts: selected supplierId=", supplierId, "cache has", productCache.length, "products");
  if (!supplierId) {
    productSelect.innerHTML = '<option value="">请先选择供应商</option>';
    productSelect.value = "";
    document.getElementById("inboundPrice").value = "";
    return;
  }
  const filtered = productCache.filter((p) => {
    const match = String(p.supplier_id) === supplierId;
    return match;
  });
  console.log("filterInboundProducts: filtered", filtered.length, "products for supplier", supplierId);
  if (filtered.length === 0) {
    productSelect.innerHTML = '<option value="">该供应商暂无商品</option>';
  } else {
    productSelect.innerHTML = '<option value="">请选择商品</option>' + optionHtml(filtered);
  }
  productSelect.value = "";
  document.getElementById("inboundPrice").value = "";
}

function syncProductPrice(selectId, priceId) {
  const select = document.getElementById(selectId);
  const price = document.getElementById(priceId);
  const product = productCache.find((item) => String(item.id) === select?.value);
  if (product && price) price.value = product.price;
}

async function loadInventory() {
  if (!hasPermission("view_inventory")) return;
  const status = document.getElementById("inventoryStatus")?.value || "";
  const rows = await api(`/api/inventory?status=${encodeURIComponent(status)}`);
  renderTable("inventoryTable", [
    { key: "sku", label: "商品编号" },
    { key: "product_name", label: "商品名称" },
    { key: "category", label: "类别" },
    { key: "supplier_name", label: "供应商" },
    { key: "stock_qty", label: "库存数量", render: (row) => `${numberFmt.format(row.stock_qty)} ${row.unit}` },
    { key: "warning_stock", label: "预警值" },
    { key: "stock_amount", label: "库存金额", render: (row) => currency.format(row.stock_amount) },
    {
      key: "stock_status",
      label: "状态",
      render: (row) => `<span class="badge ${row.stock_status === "库存预警" ? "badge-warning-stock" : "badge-normal-stock"}">${row.stock_status}</span>`,
    },
  ], rows);
}

async function loadOrders() {
  if (!hasPermission("view_orders")) return;
  const inbound = await api("/api/orders/inbound");
  renderTable("inboundTable", [
    { key: "order_no", label: "入库单号" },
    { key: "partner", label: "供应商" },
    { key: "handler", label: "经手人" },
    { key: "order_date", label: "日期" },
    { key: "total_qty", label: "数量" },
    { key: "total_amount", label: "金额", render: (row) => currency.format(row.total_amount) },
  ], inbound);

  const outbound = await api("/api/orders/outbound");
  renderTable("outboundTable", [
    { key: "order_no", label: "出库单号" },
    { key: "partner", label: "客户" },
    { key: "handler", label: "经手人" },
    { key: "order_date", label: "日期" },
    { key: "total_qty", label: "数量" },
    { key: "total_amount", label: "金额", render: (row) => currency.format(row.total_amount) },
  ], outbound);
}

const queryColumns = {
  supplier_amount: [
    { key: "supplier", label: "供应商" },
    { key: "inbound_orders", label: "入库单数", render: (row) => numberFmt.format(row.inbound_orders) },
    { key: "inbound_qty", label: "入库数量", render: (row) => numberFmt.format(row.inbound_qty) },
    { key: "inbound_amount", label: "采购金额", render: (row) => currency.format(row.inbound_amount) },
  ],
  low_stock: [
    { key: "sku", label: "商品编号" },
    { key: "product_name", label: "商品名称" },
    { key: "category", label: "类别" },
    { key: "supplier_name", label: "供应商" },
    { key: "stock_qty", label: "当前库存", render: (row) => numberFmt.format(row.stock_qty) },
    { key: "warning_stock", label: "预警线", render: (row) => numberFmt.format(row.warning_stock) },
    { key: "stock_status", label: "状态" },
  ],
  daily_flow: [
    { key: "day", label: "日期" },
    { key: "inbound_qty", label: "入库数量", render: (row) => numberFmt.format(row.inbound_qty) },
    { key: "outbound_qty", label: "出库数量", render: (row) => numberFmt.format(row.outbound_qty) },
  ],
  top_products: [
    { key: "sales_rank", label: "排名" },
    { key: "sku", label: "商品编号" },
    { key: "name", label: "商品名称" },
    { key: "category", label: "类别" },
    { key: "outbound_qty", label: "出库数量", render: (row) => numberFmt.format(row.outbound_qty) },
    { key: "outbound_amount", label: "出库金额", render: (row) => currency.format(row.outbound_amount) },
  ],
  category_amount: [
    { key: "category", label: "类别" },
    { key: "product_count", label: "商品数", render: (row) => numberFmt.format(row.product_count) },
    { key: "stock_qty", label: "库存数量", render: (row) => numberFmt.format(row.stock_qty) },
    { key: "stock_amount", label: "库存金额", render: (row) => currency.format(row.stock_amount) },
  ],
};

async function loadQuery() {
  if (!hasPermission("view_queries")) return;
  const name = document.getElementById("querySelect").value;
  const rows = await api(`/api/queries/${name}`);
  const columns = queryColumns[name] || (
    rows.length ? Object.keys(rows[0]).map((key) => ({ key, label: key })) : [{ key: "empty", label: "结果" }]
  );
  renderTable("queryTable", columns, rows);
}

async function loadUsers() {
  if (!hasPermission("manage_users")) return;
  const rows = await api("/api/users");
  renderTable("usersTable", [
    { key: "username", label: "用户名" },
    { key: "role_label", label: "当前角色" },
    {
      key: "role",
      label: "调整角色",
      render: (row) => `
        <select class="form-select form-select-sm" id="role_${row.id}">
          <option value="管理员" ${row.role === "管理员" ? "selected" : ""}>管理员</option>
          <option value="仓库员" ${row.role === "仓库员" ? "selected" : ""}>仓库员</option>
          <option value="查询员" ${row.role === "查询员" ? "selected" : ""}>查询员</option>
        </select>
      `,
    },
    {
      key: "password",
      label: "新密码",
      render: (row) => `<input class="form-control form-control-sm" id="password_${row.id}" type="password" placeholder="留空不修改">`,
    },
  ], rows, (row) => `
    <button class="btn btn-sm btn-outline-primary" onclick="updateUser(${row.id})">保存</button>
    <button class="btn btn-sm btn-outline-danger" onclick="deleteUser(${row.id})">删除</button>
  `);
}

async function loadBackupInfo() {
  if (!hasPermission("view_backup")) return;
  const data = await api("/api/backup-info");
  document.getElementById("backupInfo").innerHTML = `
    <p class="text-muted mb-0">点击下方按钮创建数据库备份，历史备份可在右侧管理恢复。</p>
  `;
  const tbody = document.getElementById("backupTable");
  if (!data.backups.length) {
    tbody.innerHTML = '<div class="text-center text-muted py-3">暂无备份，点击左侧「创建备份」按钮创建</div>';
    return;
  }
  tbody.innerHTML = `<thead><tr><th>文件名</th><th>大小</th><th>备份时间</th><th>操作</th></tr></thead><tbody>${data.backups.map((b) => `
    <tr>
      <td><code>${b.name}</code></td>
      <td>${b.size}</td>
      <td>${b.time}</td>
      <td>
        <button class="btn btn-sm btn-outline-primary me-1" onclick="restoreBackup('${b.name}')">恢复</button>
        <button class="btn btn-sm btn-outline-danger" onclick="deleteBackup('${b.name}')">删除</button>
      </td>
    </tr>
  `).join("")}</tbody>`;
}

async function createBackup() {
  const btn = document.getElementById("createBackupBtn");
  btn.disabled = true;
  btn.textContent = "备份中...";
  try {
    const result = await api("/api/backup", { method: "POST" });
    toast(result.message);
    await loadBackupInfo();
  } catch (e) {
    toast("备份失败: " + e.message);
  } finally {
    btn.disabled = false;
    btn.textContent = "创建备份";
  }
}

async function restoreBackup(name) {
  if (!confirm(`确定要从「${name}」恢复数据吗？\n当前数据将自动备份。`)) return;
  try {
    const result = await api(`/api/backup/restore/${name}`, { method: "POST" });
    toast(result.message + "，请刷新页面查看恢复后的数据。");
    await loadBackupInfo();
  } catch (e) {
    toast("恢复失败: " + e.message);
  }
}

async function deleteBackup(name) {
  if (!confirm(`确定删除备份「${name}」吗？`)) return;
  try {
    const result = await api(`/api/backup/${name}`, { method: "DELETE" });
    toast(result.message);
    await loadBackupInfo();
  } catch (e) {
    toast("删除失败: " + e.message);
  }
}

function editProduct(row) {
  document.getElementById("productId").value = row.id;
  document.getElementById("sku").value = row.sku;
  document.getElementById("productName").value = row.name;
  document.getElementById("category").value = row.category;
  document.getElementById("unit").value = row.unit;
  document.getElementById("price").value = row.price;
  document.getElementById("warningStock").value = row.warning_stock;
  document.getElementById("productSupplier").value = row.supplier_id || "";
}

function resetProductForm() {
  document.getElementById("productForm").reset();
  document.getElementById("productId").value = "";
  document.getElementById("unit").value = "件";
  document.getElementById("warningStock").value = 20;
}

function editSupplier(row) {
  document.getElementById("supplierId").value = row.id;
  document.getElementById("supplierName").value = row.name;
  document.getElementById("contact").value = row.contact;
  document.getElementById("phone").value = row.phone;
  document.getElementById("address").value = row.address || "";
  document.getElementById("supplierSubmitBtn").textContent = "保存修改";
}

function resetSupplierForm() {
  document.getElementById("supplierForm").reset();
  document.getElementById("supplierId").value = "";
  document.getElementById("supplierSubmitBtn").textContent = "新增";
}

async function deleteProduct(id) {
  if (!confirm("确定删除该商品吗？")) return;
  await api(`/api/products/${id}`, { method: "DELETE" });
  toast("商品已删除");
  await refreshAll();
}

async function deleteSupplier(id) {
  if (!confirm("确定删除该供应商吗？关联商品会变为未指定供应商。")) return;
  try {
    const result = await api(`/api/suppliers/${id}`, { method: "DELETE" });
    toast(result.message || "供应商已删除");
    await refreshAll();
  } catch (error) {
    showOperationError("删除供应商", error);
  }
}

async function updateUser(id) {
  await api(`/api/users/${id}`, {
    method: "PUT",
    body: JSON.stringify({
      role: document.getElementById(`role_${id}`).value,
      password: document.getElementById(`password_${id}`).value,
    }),
  });
  toast("用户已更新");
  await loadUsers();
}

async function deleteUser(id) {
  if (!confirm("确定删除该用户吗？")) return;
  await api(`/api/users/${id}`, { method: "DELETE" });
  toast("用户已删除");
  await loadUsers();
}

async function refreshAll() {
  await loadDashboard();
  await loadSuppliers();
  await loadProducts();
  await loadInventory();
  await loadOrders();
  await loadQuery();
  await loadUsers();
  await loadBackupInfo();
}

function bindAuthEvents() {
  document.getElementById("loginForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    clearLoginError();
    const submitBtn = document.getElementById("loginSubmitBtn");
    submitBtn.disabled = true;
    submitBtn.textContent = "登录中...";
    try {
      const data = await api("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({
          username: loginUsername.value,
          password: loginPassword.value,
        }),
      });
      toast(data.message);
      await showApp(data.user);
    } catch (error) {
      showLoginError(error.message || "用户名或密码错误");
      toast(error.message || "登录失败");
      document.getElementById("loginPassword").focus();
      document.getElementById("loginPassword").select();
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = "登录";
    }
  });

  ["loginUsername", "loginPassword"].forEach((id) => {
    document.getElementById(id).addEventListener("input", clearLoginError);
  });

  document.getElementById("logoutBtn").addEventListener("click", async () => {
    await api("/api/auth/logout", { method: "POST" });
    toast("已退出登录");
    showAuth();
  });
}

function bindBusinessEvents() {
  document.getElementById("productKeyword").addEventListener("input", loadProducts);
  document.getElementById("supplierKeyword").addEventListener("input", loadSuppliers);
  document.getElementById("inventoryStatus").addEventListener("change", loadInventory);
  document.getElementById("querySelect").addEventListener("change", loadQuery);
  document.getElementById("inboundSupplier").addEventListener("change", filterInboundProducts);
  document.getElementById("inboundProduct").addEventListener("change", () => syncProductPrice("inboundProduct", "inboundPrice"));
  document.getElementById("outboundProduct").addEventListener("change", () => syncProductPrice("outboundProduct", "outboundPrice"));

  document.getElementById("supplierForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const id = document.getElementById("supplierId").value;
    const payload = {
      name: supplierName.value,
      contact: contact.value,
      phone: phone.value,
      address: address.value,
    };
    try {
      const result = await api(id ? `/api/suppliers/${id}` : "/api/suppliers", {
        method: id ? "PUT" : "POST",
        body: JSON.stringify(payload),
      });
      resetSupplierForm();
      toast(result.message || "供应商保存成功");
      await refreshAll();
    } catch (error) {
      showOperationError("保存供应商", error);
    }
  });

  document.getElementById("productForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const id = document.getElementById("productId").value;
    const payload = {
      sku: sku.value,
      name: productName.value,
      category: category.value,
      unit: unit.value,
      price: price.value,
      warning_stock: warningStock.value,
      supplier_id: productSupplier.value,
    };
    await api(id ? `/api/products/${id}` : "/api/products", {
      method: id ? "PUT" : "POST",
      body: JSON.stringify(payload),
    });
    resetProductForm();
    toast("商品保存成功");
    await refreshAll();
  });

  document.getElementById("inboundForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    await api("/api/inbound", {
      method: "POST",
      body: JSON.stringify({
        supplier_id: inboundSupplier.value,
        product_id: inboundProduct.value,
        quantity: inboundQty.value,
        unit_price: inboundPrice.value,
        handler: inboundHandler.value,
      }),
    });
    event.target.reset();
    document.getElementById("inboundHandler").value = "经手人";
    syncProductPrice("inboundProduct", "inboundPrice");
    toast("入库登记成功");
    await refreshAll();
  });

  document.getElementById("outboundForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    await api("/api/outbound", {
      method: "POST",
      body: JSON.stringify({
        customer: customer.value,
        product_id: outboundProduct.value,
        quantity: outboundQty.value,
        unit_price: outboundPrice.value,
        handler: outboundHandler.value,
      }),
    });
    event.target.reset();
    document.getElementById("customer").value = "普通客户";
    document.getElementById("outboundHandler").value = "经手人";
    syncProductPrice("outboundProduct", "outboundPrice");
    toast("出库登记成功");
    await refreshAll();
  });

  document.getElementById("userForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    await api("/api/users", {
      method: "POST",
      body: JSON.stringify({
        username: newUsername.value,
        password: newPassword.value,
        role: newRole.value,
      }),
    });
    event.target.reset();
    toast("用户创建成功");
    await loadUsers();
  });

  document.getElementById("aiForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const answerBox = document.getElementById("aiAnswer");
    answerBox.textContent = "正在处理...";
    answerBox.classList.remove("text-secondary");
    try {
      const data = await api("/api/ai/chat", {
        method: "POST",
        body: JSON.stringify({ message: aiMessage.value }),
      });
      answerBox.innerHTML = renderMarkdown(data.answer);
    } catch (error) {
      answerBox.textContent = error.message;
    }
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  bindAuthEvents();
  bindBusinessEvents();
  try {
    const data = await api("/api/auth/me");
    if (data.user) {
      await showApp(data.user);
    } else {
      showAuth();
    }
  } catch (error) {
    showAuth();
  }
});
