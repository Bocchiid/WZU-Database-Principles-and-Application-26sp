from __future__ import annotations

import os

from inventory_app import create_app
from inventory_app.db import init_db


app = create_app()


if __name__ == "__main__":
    init_db(force=os.getenv("RESET_DB") == "1")
    debug = os.getenv("FLASK_DEBUG") == "1"
    app.run(debug=debug, use_reloader=debug, host="127.0.0.1", port=int(os.getenv("PORT", "5000")))
