# 小型进销存管理系统

本项目用于“数据库原理与应用”期末大作业，技术栈为 Flask + HTML/CSS/JavaScript + Bootstrap，数据库使用 MySQL 8.0。

## 功能模块

- 商品管理：商品新增、修改、删除、查询
- 供应商管理：供应商新增、修改、删除、查询
- 入库管理：生成入库单并自动增加库存
- 出库管理：生成出库单并自动扣减库存，库存不足时阻止出库
- 库存管理：库存总览、库存金额、库存预警
- 复杂查询：供应商入库金额、低库存商品、每日出入库、商品出库排行、分类库存金额
- 数据库对象：表、主键、外键、检查约束、索引、视图、触发器

## 运行方式

```powershell
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

浏览器打开：

```text
http://127.0.0.1:5000
```

## 重置测试数据

访问以下地址可以重新建库并生成测试数据：

```text
http://127.0.0.1:5000/reset
```

## 可写入的数据库说明

系统至少包含 `suppliers`、`products`、`inbound_orders`、`inbound_items`、`outbound_orders`、`outbound_items`、`inventory`、`users` 等数据表。系统使用触发器维护库存数量，使用视图 `v_inventory_detail` 展示库存明细，使用索引优化按日期、商品、供应商等维度的查询。

## MySQL 8.0 配置

先确认 MySQL 8.0 服务已经启动，并创建或准备好可登录账号。系统会自动创建 `MYSQL_DATABASE` 指定的数据库。

可以复制 `.env.example` 为 `.env`，按本机 MySQL 信息修改：

```text
DEEPSEEK_API_KEY=your deepseek api key
MYSQL_HOST=127.0.0.1
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=your mysql password
MYSQL_DATABASE=inventory_system
MYSQL_CHARSET=utf8mb4
```

## 项目结构

```text
app.py                       # 项目启动入口
inventory_app/
  __init__.py                # Flask 应用工厂与蓝图注册
  config.py                  # 路径、环境变量等配置
  db.py                      # 数据库连接、建表、测试数据初始化
  auth.py                    # 登录状态、角色权限与密码验证
  routes/
    main.py                  # 首页、重置数据、看板接口
    auth_routes.py           # 登录、注册、退出接口
    products.py              # 商品管理接口
    suppliers.py             # 供应商管理接口
    inventory.py             # 库存查询接口
    orders.py                # 入库、出库和单据查询接口
    queries.py               # 复杂 SQL 经营分析接口
    users.py                 # 用户与角色权限接口
    backup.py                # 数据备份与恢复接口
    ai.py                    # 智能查询助理接口
templates/index.html         # 前端页面模板
static/css/style.css         # 页面样式
static/js/app.js             # 前端交互逻辑
```
