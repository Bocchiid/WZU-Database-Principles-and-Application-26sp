from __future__ import annotations

from functools import wraps

from flask import jsonify, session
from werkzeug.security import check_password_hash, generate_password_hash

from .db import get_db, query_one


ROLES = ("管理员", "仓库员", "查询员")
ROLE_LABELS = {
    "管理员": "管理员",
    "仓库员": "仓库员",
    "查询员": "查询员",
}
ROLE_PERMISSIONS = {
    "管理员": {
        "view_dashboard",
        "view_products",
        "manage_products",
        "view_suppliers",
        "manage_suppliers",
        "view_inventory",
        "view_orders",
        "create_stock_flow",
        "view_queries",
        "view_reports",
        "manage_users",
        "view_backup",
        "use_ai",
    },
    "仓库员": {
        "view_dashboard",
        "view_products",
        "view_suppliers",
        "view_inventory",
        "view_orders",
        "create_stock_flow",
        "use_ai",
    },
    "查询员": {
        "view_dashboard",
        "view_products",
        "view_suppliers",
        "view_inventory",
        "view_queries",
        "view_reports",
        "use_ai",
    },
}


def public_user(row: dict) -> dict:
    role = row["role"]
    return {
        "id": row["id"],
        "username": row["username"],
        "role": role,
        "role_label": ROLE_LABELS.get(role, role),
        "permissions": sorted(ROLE_PERMISSIONS.get(role, set())),
    }


def current_user() -> dict | None:
    user_id = session.get("user_id")
    if not user_id:
        return None
    return query_one("SELECT id, username, role FROM users WHERE id = ?", (user_id,))


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if current_user() is None:
            return jsonify({"message": "请先登录"}), 401
        return view(*args, **kwargs)

    return wrapped


def permission_required(permission: str):
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapped(*args, **kwargs):
            user = current_user()
            permissions = ROLE_PERMISSIONS.get(user["role"], set()) if user else set()
            if permission not in permissions:
                return jsonify({"message": "当前角色无权执行该操作"}), 403
            return view(*args, **kwargs)

        return wrapped

    return decorator


def verify_password(user: dict, password: str) -> bool:
    stored = user["password"]
    if stored.startswith(("pbkdf2:", "scrypt:")):
        return check_password_hash(stored, password)
    if stored == password:
        with get_db() as conn:
            conn.execute("UPDATE users SET password = ? WHERE id = ?", (generate_password_hash(password), user["id"]))
        return True
    return False
