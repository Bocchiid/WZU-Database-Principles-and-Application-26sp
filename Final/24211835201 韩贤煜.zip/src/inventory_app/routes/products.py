from __future__ import annotations

from flask import Blueprint, jsonify, request

from ..auth import permission_required
from ..db import get_db, query_all


bp = Blueprint("products", __name__)


@bp.get("/api/products")
@permission_required("view_products")
def products():
    keyword = request.args.get("keyword", "").strip()
    rows = query_all(
        """
        SELECT p.*, COALESCE(s.name, '未指定') AS supplier_name
        FROM products p
        LEFT JOIN suppliers s ON s.id = p.supplier_id
        WHERE ? = '' OR p.name LIKE ? OR p.sku LIKE ? OR p.category LIKE ?
        ORDER BY p.id DESC
        """,
        (keyword, f"%{keyword}%", f"%{keyword}%", f"%{keyword}%"),
    )
    return jsonify(rows)


@bp.post("/api/products")
@permission_required("manage_products")
def create_product():
    data = request.get_json(force=True)
    with get_db() as conn:
        conn.execute(
            """
            INSERT INTO products(sku, name, category, unit, price, warning_stock, supplier_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                data["sku"].strip(),
                data["name"].strip(),
                data["category"].strip(),
                data.get("unit", "件").strip(),
                float(data["price"]),
                int(data.get("warning_stock", 20)),
                int(data["supplier_id"]) if data.get("supplier_id") else None,
            ),
        )
    return jsonify({"message": "商品添加成功"})


@bp.put("/api/products/<int:product_id>")
@permission_required("manage_products")
def update_product(product_id: int):
    data = request.get_json(force=True)
    with get_db() as conn:
        conn.execute(
            """
            UPDATE products
            SET sku = ?, name = ?, category = ?, unit = ?, price = ?, warning_stock = ?, supplier_id = ?
            WHERE id = ?
            """,
            (
                data["sku"].strip(),
                data["name"].strip(),
                data["category"].strip(),
                data.get("unit", "件").strip(),
                float(data["price"]),
                int(data.get("warning_stock", 20)),
                int(data["supplier_id"]) if data.get("supplier_id") else None,
                product_id,
            ),
        )
    return jsonify({"message": "商品更新成功"})


@bp.delete("/api/products/<int:product_id>")
@permission_required("manage_products")
def delete_product(product_id: int):
    with get_db() as conn:
        conn.execute("DELETE FROM products WHERE id = ?", (product_id,))
    return jsonify({"message": "商品删除成功"})
