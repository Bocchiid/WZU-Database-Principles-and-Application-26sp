from __future__ import annotations

import json
import os
import re
import urllib.error
import urllib.request

from flask import Blueprint, jsonify, request

from ..auth import permission_required
from ..db import DatabaseError, query_all


bp = Blueprint("ai", __name__)


SQL_SCHEMA_PROMPT = """
你只能为 MySQL 8.0 生成只读 SELECT 查询，不能生成 INSERT/UPDATE/DELETE/DROP/ALTER/CREATE/SHOW。
可用表和字段：
v_inventory_detail(product_id, sku, product_name, category, unit, price, warning_stock, supplier_name, stock_qty, stock_amount, stock_status)
products(id, sku, name, category, unit, price, warning_stock, supplier_id, created_at)
suppliers(id, name, contact, phone, address, created_at)
inbound_orders(id, order_no, supplier_id, handler, order_date, remark)
inbound_items(id, inbound_order_id, product_id, quantity, unit_price)
outbound_orders(id, order_no, customer, handler, order_date, remark)
outbound_items(id, outbound_order_id, product_id, quantity, unit_price)
只返回 JSON：{"sql":"SELECT ...","summary":"一句话说明查询目的"}。
查询必须带 LIMIT，除非是聚合结果。
"""


def is_safe_select_sql(sql: str) -> bool:
    normalized = re.sub(r"\s+", " ", sql.strip(), flags=re.M).lower()
    if not normalized.startswith(("select ", "with ")):
        return False
    if ";" in normalized.rstrip(";"):
        return False
    blocked = (
        " insert ",
        " update ",
        " delete ",
        " drop ",
        " alter ",
        " create ",
        " replace ",
        " attach ",
        " detach ",
        " pragma ",
        " vacuum ",
        " truncate ",
        " show ",
    )
    padded = f" {normalized} "
    return not any(word in padded for word in blocked)


def find_product_keyword(message: str) -> str | None:
    normalized = message.strip().lower()
    for product in query_all("SELECT sku, name FROM products ORDER BY id"):
        if product["sku"].lower() in normalized or product["name"].lower() in normalized:
            return product["sku"]

    sku = re.search(r"\bsp\d{4,}\b", normalized, flags=re.I)
    if sku:
        return sku.group(0).upper()

    product_name = re.search(r"[\u4e00-\u9fffA-Za-z0-9]+商品\d+", message)
    if product_name:
        return product_name.group(0)
    return None


def local_sql_from_message(message: str) -> tuple[str, tuple, str] | None:
    product_keyword = find_product_keyword(message)
    stock_words = ("库存", "还有", "剩余", "剩", "数量")

    if product_keyword and any(word in message for word in stock_words):
        return (
            """
            SELECT sku, product_name, category, supplier_name, stock_qty, unit, warning_stock, stock_status, stock_amount
            FROM v_inventory_detail
            WHERE sku = ? OR product_name = ? OR product_name LIKE ?
            ORDER BY sku
            LIMIT 10
            """,
            (product_keyword, product_keyword, f"%{product_keyword}%"),
            "查询指定商品库存",
        )

    if any(word in message for word in ("低库存", "库存预警", "预警商品")):
        return (
            """
            SELECT sku, product_name, category, supplier_name, stock_qty, unit, warning_stock, stock_status
            FROM v_inventory_detail
            WHERE stock_qty <= warning_stock
            ORDER BY stock_qty ASC, sku
            LIMIT 50
            """,
            (),
            "查询库存预警商品",
        )

    if product_keyword:
        return (
            """
            SELECT sku, product_name, category, supplier_name, stock_qty, unit, price, warning_stock, stock_status
            FROM v_inventory_detail
            WHERE sku = ? OR product_name = ? OR product_name LIKE ?
            ORDER BY sku
            LIMIT 10
            """,
            (product_keyword, product_keyword, f"%{product_keyword}%"),
            "查询商品档案与库存",
        )

    if "供应商" in message and any(word in message for word in ("金额", "采购", "入库", "排行", "排名")):
        return (
            """
            SELECT s.name AS supplier,
                   COUNT(DISTINCT o.id) AS inbound_orders,
                   COALESCE(SUM(i.quantity), 0) AS inbound_qty,
                   ROUND(COALESCE(SUM(i.quantity * i.unit_price), 0), 2) AS inbound_amount
            FROM suppliers s
            LEFT JOIN inbound_orders o ON o.supplier_id = s.id
            LEFT JOIN inbound_items i ON i.inbound_order_id = o.id
            GROUP BY s.id, s.name
            ORDER BY inbound_amount DESC
            LIMIT 20
            """,
            (),
            "查询供应商采购金额",
        )

    if any(word in message for word in ("排行", "排名", "出库最多", "卖得最多")):
        return (
            """
            SELECT p.sku, p.name, p.category,
                   COALESCE(SUM(oi.quantity), 0) AS outbound_qty,
                   ROUND(COALESCE(SUM(oi.quantity * oi.unit_price), 0), 2) AS outbound_amount,
                   RANK() OVER (ORDER BY COALESCE(SUM(oi.quantity), 0) DESC) AS sales_rank
            FROM products p
            LEFT JOIN outbound_items oi ON oi.product_id = p.id
            GROUP BY p.id, p.sku, p.name, p.category
            ORDER BY outbound_qty DESC
            LIMIT 10
            """,
            (),
            "查询出库商品排行",
        )

    if any(word in message for word in ("品类", "分类", "类别")) and any(word in message for word in ("库存", "金额", "资产")):
        return (
            """
            SELECT category,
                   COUNT(*) AS product_count,
                   COALESCE(SUM(stock_qty), 0) AS stock_qty,
                   ROUND(COALESCE(SUM(stock_amount), 0), 2) AS stock_amount
            FROM v_inventory_detail
            GROUP BY category
            ORDER BY stock_amount DESC
            """,
            (),
            "查询品类库存资产",
        )

    if any(word in message for word in ("每日", "每天", "趋势", "流水")):
        return (
            """
            SELECT day, COALESCE(SUM(in_qty), 0) AS inbound_qty, COALESCE(SUM(out_qty), 0) AS outbound_qty
            FROM (
                SELECT order_date AS day, SUM(quantity) AS in_qty, 0 AS out_qty
                FROM inbound_orders o JOIN inbound_items i ON i.inbound_order_id = o.id
                GROUP BY order_date
                UNION ALL
                SELECT order_date AS day, 0 AS in_qty, SUM(quantity) AS out_qty
                FROM outbound_orders o JOIN outbound_items i ON i.outbound_order_id = o.id
                GROUP BY order_date
            ) AS flow_data
            GROUP BY day
            ORDER BY day DESC
            LIMIT 20
            """,
            (),
            "查询出入库趋势",
        )

    return None


COLUMN_NAME_MAP: dict[str, str] = {
    "sku": "商品编号",
    "product_name": "商品名称",
    "name": "名称",
    "category": "类别",
    "unit": "单位",
    "price": "单价",
    "warning_stock": "预警库存",
    "supplier_name": "供应商",
    "stock_qty": "库存数量",
    "stock_amount": "库存金额",
    "stock_status": "库存状态",
    "supplier": "供应商",
    "inbound_orders": "入库单数",
    "inbound_qty": "入库数量",
    "inbound_amount": "入库金额",
    "outbound_qty": "出库数量",
    "outbound_amount": "出库金额",
    "sales_rank": "销售排名",
    "product_count": "商品数量",
    "day": "日期",
}


def chinese_column(name: str) -> str:
    return COLUMN_NAME_MAP.get(name, name)


def markdown_table(rows: list[dict]) -> str:
    if not rows:
        return "未查询到匹配数据。"
    columns = list(rows[0].keys())
    cn_columns = [chinese_column(c) for c in columns]
    header = "| " + " | ".join(cn_columns) + " |"
    separator = "| " + " | ".join(["---"] * len(columns)) + " |"
    body = []
    for row in rows[:20]:
        body.append("| " + " | ".join(str(row.get(column, "")) for column in columns) + " |")
    return "\n".join([header, separator, *body])


def answer_from_sql_result(summary: str, sql: str, args: tuple, rows: list[dict]) -> str:
    if "指定商品库存" in summary and len(rows) == 1:
        row = rows[0]
        main_answer = (
            f"{row['product_name']}（{row['sku']}）当前库存为 **{row['stock_qty']} {row['unit']}**，"
            f"状态：**{row['stock_status']}**，预警线：{row['warning_stock']} {row['unit']}。"
        )
    elif rows:
        main_answer = f"{summary}，共查到 **{len(rows)}** 条记录。"
    else:
        main_answer = f"{summary}，未查询到匹配数据。"

    params_text = f"\n参数：`{args}`" if args else ""
    return (
        f"{main_answer}\n\n"
        f"执行 SQL：\n```sql\n{sql.strip()}\n```\n"
        f"{params_text}\n\n"
        f"查询结果：\n{markdown_table(rows)}"
    )


def deepseek_sql_from_message(message: str) -> tuple[str, str] | None:
    api_key = os.getenv("DEEPSEEK_API_KEY")
    if not api_key:
        return None

    payload = {
        "model": os.getenv("DEEPSEEK_MODEL", "deepseek-chat"),
        "messages": [
            {"role": "system", "content": SQL_SCHEMA_PROMPT},
            {"role": "user", "content": message},
        ],
        "temperature": 0,
        "response_format": {"type": "json_object"},
    }
    request_data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        os.getenv("DEEPSEEK_API_URL", "https://api.deepseek.com/chat/completions"),
        data=request_data,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=30) as response:
        result = json.loads(response.read().decode("utf-8"))
    content = result.get("choices", [{}])[0].get("message", {}).get("content", "{}")
    parsed = json.loads(content)
    sql = parsed.get("sql", "").strip().rstrip(";")
    summary = parsed.get("summary", "查询数据")
    return (sql, summary) if sql else None


@bp.post("/api/ai/chat")
@permission_required("use_ai")
def ai_chat():
    data = request.get_json(force=True)
    message = data.get("message", "").strip()
    if not message:
        return jsonify({"message": "请输入要咨询的问题"}), 400

    business_keywords = (
        "库存", "商品", "供应商", "入库", "出库", "排行", "排名", "金额",
        "采购", "销售", "品类", "分类", "类别", "趋势", "流水", "预警",
    )
    if len(message) < 2 or not any(keyword in message for keyword in business_keywords):
        return jsonify({
            "answer": "我没有识别到明确的数据查询条件。请说明要查的商品、供应商、库存、出入库或报表指标。"
        })

    local_query = local_sql_from_message(message)
    if local_query:
        sql, args, summary = local_query
        rows = query_all(sql, args)
        return jsonify({"answer": answer_from_sql_result(summary, sql, args, rows), "sql": sql.strip(), "rows": rows})

    try:
        generated = deepseek_sql_from_message(message)
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="ignore")
        try:
            error_payload = json.loads(detail)
            error_message = error_payload.get("error", {}).get("message", "")
        except json.JSONDecodeError:
            error_message = detail or str(exc.reason)

        if "insufficient balance" in error_message.lower():
            message = "DeepSeek 账户余额不足，请充值或更换可用的 API Key。"
        else:
            message = f"DeepSeek 调用失败：{error_message or exc.reason}"
        return jsonify({"message": message}), 502
    except urllib.error.URLError as exc:
        return jsonify({"message": f"DeepSeek 网络连接失败：{exc.reason}"}), 502
    except (json.JSONDecodeError, KeyError, TypeError) as exc:
        return jsonify({"message": f"SQL 生成失败：{exc}"}), 502

    if not generated:
        return jsonify({"answer": "我没有识别到明确的数据查询条件。请说明要查的商品、供应商、库存、出入库或报表指标。"})

    sql, summary = generated
    if not is_safe_select_sql(sql):
        return jsonify({"message": "生成的 SQL 不是安全的只读查询，已拒绝执行。"}), 400

    try:
        rows = query_all(sql)
    except DatabaseError as exc:
        return jsonify({"message": f"SQL 执行失败：{exc}"}), 400
    return jsonify({"answer": answer_from_sql_result(summary, sql, (), rows), "sql": sql.strip(), "rows": rows})
