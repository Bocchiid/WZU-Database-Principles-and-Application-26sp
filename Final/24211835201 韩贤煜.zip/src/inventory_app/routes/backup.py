from __future__ import annotations

import json
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path

from flask import Blueprint, jsonify

from ..auth import permission_required
from ..config import BACKUP_DIR
from ..db import get_db, query_all


bp = Blueprint("backup", __name__)
BACKUP_DIR.mkdir(exist_ok=True)

BACKUP_TABLES = [
    "suppliers",
    "products",
    "inbound_orders",
    "inbound_items",
    "outbound_orders",
    "outbound_items",
    "users",
]
RESTORE_CLEAR_TABLES = [*BACKUP_TABLES, "inventory"]


def json_default(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return float(value)
    raise TypeError(f"{type(value).__name__} is not JSON serializable")


def safe_backup_path(filename: str) -> Path | None:
    if "/" in filename or "\\" in filename or not filename.endswith(".json"):
        return None
    return BACKUP_DIR / filename


@bp.get("/api/backup-info")
@permission_required("view_backup")
def backup_info():
    backups = sorted(BACKUP_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    backup_list = []
    for p in backups:
        size = p.stat().st_size
        if size < 1024:
            size_str = f"{size} B"
        elif size < 1024 * 1024:
            size_str = f"{size / 1024:.1f} KB"
        else:
            size_str = f"{size / 1024 / 1024:.1f} MB"
        backup_list.append(
            {
                "name": p.name,
                "size": size_str,
                "time": datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
            }
        )
    return jsonify({"backups": backup_list})


@bp.post("/api/backup")
@permission_required("view_backup")
def create_backup():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_name = f"backup_{timestamp}.json"
    backup_path = BACKUP_DIR / backup_name
    try:
        payload = {
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "database": "mysql",
            "tables": {table: query_all(f"SELECT * FROM {table} ORDER BY 1") for table in BACKUP_TABLES},
        }
        backup_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=json_default), encoding="utf-8")
        return jsonify({"success": True, "name": backup_name, "message": "备份创建成功"})
    except Exception as exc:
        return jsonify({"success": False, "message": f"备份失败: {exc}"}), 500


@bp.post("/api/backup/restore/<filename>")
@permission_required("view_backup")
def restore_backup(filename):
    backup_path = safe_backup_path(filename)
    if backup_path is None:
        return jsonify({"success": False, "message": "无效的备份文件"}), 400
    if not backup_path.exists():
        return jsonify({"success": False, "message": "备份文件不存在"}), 404

    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        auto_backup = BACKUP_DIR / f"pre_restore_{timestamp}.json"
        payload = {
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "database": "mysql",
            "tables": {table: query_all(f"SELECT * FROM {table} ORDER BY 1") for table in BACKUP_TABLES},
        }
        auto_backup.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=json_default), encoding="utf-8")

        data = json.loads(backup_path.read_text(encoding="utf-8"))
        tables = data.get("tables", {})
        with get_db() as conn:
            conn.execute("SET FOREIGN_KEY_CHECKS = 0")
            for table in reversed(RESTORE_CLEAR_TABLES):
                conn.execute(f"DELETE FROM {table}")
            conn.execute("SET FOREIGN_KEY_CHECKS = 1")

            for table in BACKUP_TABLES:
                rows = tables.get(table, [])
                if not rows:
                    continue
                columns = list(rows[0].keys())
                placeholders = ", ".join(["?"] * len(columns))
                col_sql = ", ".join(f"`{column}`" for column in columns)
                sql = f"INSERT INTO {table}({col_sql}) VALUES ({placeholders})"
                conn.executemany(sql, ([row.get(column) for column in columns] for row in rows))

        return jsonify({"success": True, "message": f"已从 {filename} 恢复，恢复前数据已备份为 {auto_backup.name}"})
    except Exception as exc:
        return jsonify({"success": False, "message": f"恢复失败: {exc}"}), 500


@bp.delete("/api/backup/<filename>")
@permission_required("view_backup")
def delete_backup(filename):
    backup_path = safe_backup_path(filename)
    if backup_path is None:
        return jsonify({"success": False, "message": "无效的备份文件"}), 400
    if not backup_path.exists():
        return jsonify({"success": False, "message": "备份文件不存在"}), 404
    try:
        backup_path.unlink()
        return jsonify({"success": True, "message": f"已删除备份 {filename}"})
    except Exception as exc:
        return jsonify({"success": False, "message": f"删除失败: {exc}"}), 500
