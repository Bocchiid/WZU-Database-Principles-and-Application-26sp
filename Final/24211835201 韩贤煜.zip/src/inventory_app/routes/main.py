from __future__ import annotations

from flask import Blueprint, jsonify, redirect, render_template, url_for

from ..auth import permission_required
from ..db import init_db, query_all, query_one


bp = Blueprint("main", __name__)


@bp.route("/")
def index():
    return render_template("index.html")


@bp.route("/reset")
def reset():
    init_db(force=True)
    return redirect(url_for("main.index"))


@bp.get("/api/dashboard")
@permission_required("view_dashboard")
def dashboard():
    cards = query_one(
        """
        SELECT
            (SELECT COUNT(*) FROM products) AS product_count,
            (SELECT COUNT(*) FROM suppliers) AS supplier_count,
            (SELECT COUNT(*) FROM inbound_orders) AS inbound_count,
            (SELECT COUNT(*) FROM outbound_orders) AS outbound_count,
            (SELECT COUNT(*) FROM v_inventory_detail WHERE stock_status = '库存预警') AS warning_count,
            (SELECT ROUND(COALESCE(SUM(stock_amount), 0), 2) FROM v_inventory_detail) AS stock_amount
        """
    )
    category_stock = query_all(
        """
        SELECT category, SUM(stock_qty) AS stock_qty, ROUND(SUM(stock_amount), 2) AS amount
        FROM v_inventory_detail
        GROUP BY category
        ORDER BY amount DESC
        """
    )
    recent_flow = query_all(
        """
        SELECT day, SUM(in_qty) AS inbound_qty, SUM(out_qty) AS outbound_qty
        FROM (
            SELECT order_date AS day, SUM(quantity) AS in_qty, 0 AS out_qty
            FROM inbound_orders o
            JOIN inbound_items i ON i.inbound_order_id = o.id
            GROUP BY order_date
            UNION ALL
            SELECT order_date AS day, 0 AS in_qty, SUM(quantity) AS out_qty
            FROM outbound_orders o
            JOIN outbound_items i ON i.outbound_order_id = o.id
            GROUP BY order_date
        ) AS flow_data
        GROUP BY day
        ORDER BY day DESC
        LIMIT 10
        """
    )
    return jsonify({"cards": cards, "category_stock": category_stock, "recent_flow": list(reversed(recent_flow))})
