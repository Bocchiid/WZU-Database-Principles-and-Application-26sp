from __future__ import annotations

from flask import Blueprint, jsonify, request, session
from werkzeug.security import generate_password_hash

from ..auth import ROLE_LABELS, ROLE_PERMISSIONS, ROLES, login_required, permission_required, public_user
from ..db import get_db, query_all


bp = Blueprint("users", __name__)


@bp.get("/api/users")
@permission_required("manage_users")
def list_users():
    rows = query_all("SELECT id, username, role FROM users ORDER BY id")
    return jsonify([public_user(row) for row in rows])


@bp.post("/api/users")
@permission_required("manage_users")
def create_user():
    data = request.get_json(force=True)
    username = data.get("username", "").strip()
    password = data.get("password", "")
    role = data.get("role", "查询员")
    if role not in ROLES:
        return jsonify({"message": "角色不存在"}), 400
    if len(username) < 3:
        return jsonify({"message": "用户名至少需要 3 个字符"}), 400
    if len(password) < 6:
        return jsonify({"message": "密码至少需要 6 位"}), 400
    with get_db() as conn:
        conn.execute(
            "INSERT INTO users(username, role, password) VALUES (?, ?, ?)",
            (username, role, generate_password_hash(password)),
        )
    return jsonify({"message": "用户添加成功"})


@bp.put("/api/users/<int:user_id>")
@permission_required("manage_users")
def update_user(user_id: int):
    data = request.get_json(force=True)
    role = data.get("role")
    password = data.get("password", "")
    if role not in ROLES:
        return jsonify({"message": "角色不存在"}), 400
    with get_db() as conn:
        if password:
            if len(password) < 6:
                return jsonify({"message": "密码至少需要 6 位"}), 400
            conn.execute(
                "UPDATE users SET role = ?, password = ? WHERE id = ?",
                (role, generate_password_hash(password), user_id),
            )
        else:
            conn.execute("UPDATE users SET role = ? WHERE id = ?", (role, user_id))
    return jsonify({"message": "用户更新成功"})


@bp.delete("/api/users/<int:user_id>")
@permission_required("manage_users")
def delete_user(user_id: int):
    if session.get("user_id") == user_id:
        return jsonify({"message": "不能删除当前登录用户"}), 400
    with get_db() as conn:
        conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
    return jsonify({"message": "用户删除成功"})


@bp.get("/api/roles")
@login_required
def roles():
    return jsonify(
        [
            {
                "name": role,
                "label": ROLE_LABELS[role],
                "permissions": sorted(ROLE_PERMISSIONS[role]),
            }
            for role in ROLES
        ]
    )
