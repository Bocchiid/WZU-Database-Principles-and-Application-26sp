from __future__ import annotations

from flask import Blueprint, jsonify, request

from ..auth import permission_required
from ..db import query_all


bp = Blueprint("inventory", __name__)


@bp.get("/api/inventory")
@permission_required("view_inventory")
def inventory():
    status = request.args.get("status", "")
    rows = query_all(
        """
        SELECT *
        FROM v_inventory_detail
        WHERE ? = '' OR stock_status = ?
        ORDER BY stock_status DESC, stock_qty ASC
        """,
        (status, status),
    )
    return jsonify(rows)
