from __future__ import annotations

from flask import Flask

from . import ai, auth_routes, backup, inventory, main, orders, products, queries, suppliers, users


def register_blueprints(app: Flask) -> None:
    for blueprint in (
        main.bp,
        auth_routes.bp,
        products.bp,
        suppliers.bp,
        inventory.bp,
        orders.bp,
        queries.bp,
        users.bp,
        backup.bp,
        ai.bp,
    ):
        app.register_blueprint(blueprint)
