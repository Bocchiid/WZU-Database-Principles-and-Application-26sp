from __future__ import annotations

from datetime import date, datetime

from flask import Blueprint, jsonify, request

from ..auth import permission_required
from ..db import DatabaseIntegrityError, get_db, query_all


bp = Blueprint("orders", __name__)


@bp.get("/api/orders/<order_type>")
@permission_required("view_orders")
def orders(order_type: str):
    if order_type == "inbound":
        rows = query_all(
            """
            SELECT o.id, o.order_no, s.name AS partner, o.handler, o.order_date,
                   SUM(i.quantity) AS total_qty,
                   ROUND(SUM(i.quantity * i.unit_price), 2) AS total_amount
            FROM inbound_orders o
            JOIN suppliers s ON s.id = o.supplier_id
            JOIN inbound_items i ON i.inbound_order_id = o.id
            GROUP BY o.id, o.order_no, s.name, o.handler, o.order_date
            ORDER BY o.order_date DESC, o.id DESC
            LIMIT 80
            """
        )
    else:
        rows = query_all(
            """
            SELECT o.id, o.order_no, o.customer AS partner, o.handler, o.order_date,
                   SUM(i.quantity) AS total_qty,
                   ROUND(SUM(i.quantity * i.unit_price), 2) AS total_amount
            FROM outbound_orders o
            JOIN outbound_items i ON i.outbound_order_id = o.id
            GROUP BY o.id, o.order_no, o.customer, o.handler, o.order_date
            ORDER BY o.order_date DESC, o.id DESC
            LIMIT 80
            """
        )
    return jsonify(rows)


@bp.post("/api/inbound")
@permission_required("create_stock_flow")
def create_inbound():
    data = request.get_json(force=True)
    with get_db() as conn:
        cursor = conn.execute(
            """
            INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                f"RK{datetime.now():%Y%m%d%H%M%S}",
                int(data["supplier_id"]),
                data.get("handler", "仓库员"),
                data.get("order_date") or date.today().isoformat(),
                data.get("remark", ""),
            ),
        )
        conn.execute(
            """
            INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
            VALUES (?, ?, ?, ?)
            """,
            (cursor.lastrowid, int(data["product_id"]), int(data["quantity"]), float(data["unit_price"])),
        )
    return jsonify({"message": "入库成功，库存已自动增加"})


@bp.post("/api/outbound")
@permission_required("create_stock_flow")
def create_outbound():
    data = request.get_json(force=True)
    try:
        with get_db() as conn:
            cursor = conn.execute(
                """
                INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    f"CK{datetime.now():%Y%m%d%H%M%S}",
                    data.get("customer", "普通客户").strip(),
                    data.get("handler", "仓库员"),
                    data.get("order_date") or date.today().isoformat(),
                    data.get("remark", ""),
                ),
            )
            conn.execute(
                """
                INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
                VALUES (?, ?, ?, ?)
                """,
                (cursor.lastrowid, int(data["product_id"]), int(data["quantity"]), float(data["unit_price"])),
            )
    except DatabaseIntegrityError as exc:
        return jsonify({"message": exc.args[-1] if exc.args else str(exc)}), 400
    return jsonify({"message": "出库成功，库存已自动扣减"})
