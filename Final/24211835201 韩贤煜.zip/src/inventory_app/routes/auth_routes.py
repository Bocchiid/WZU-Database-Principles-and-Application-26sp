from __future__ import annotations

from flask import Blueprint, jsonify, request, session

from ..auth import current_user, login_required, public_user, verify_password
from ..db import query_one


bp = Blueprint("auth_routes", __name__)


@bp.get("/api/auth/me")
def auth_me():
    user = current_user()
    return jsonify({"user": public_user(user) if user else None})


@bp.post("/api/auth/login")
def login():
    data = request.get_json(force=True)
    username = data.get("username", "").strip()
    password = data.get("password", "")
    user = query_one("SELECT id, username, role, password FROM users WHERE username = ?", (username,))
    if not user or not verify_password(user, password):
        return jsonify({"message": "用户名或密码错误"}), 400
    session["user_id"] = user["id"]
    return jsonify({"message": "登录成功", "user": public_user(user)})


@bp.post("/api/auth/logout")
@login_required
def logout():
    session.clear()
    return jsonify({"message": "已退出登录"})
