from __future__ import annotations

from flask import Blueprint, jsonify

from ..auth import permission_required
from ..db import query_all


bp = Blueprint("queries", __name__)


REPORT_SQL = {
    "supplier_amount": """
        SELECT
            s.name AS supplier,
            COUNT(DISTINCT o.id) AS inbound_orders,
            COALESCE(SUM(i.quantity), 0) AS inbound_qty,
            ROUND(COALESCE(SUM(i.quantity * i.unit_price), 0), 2) AS inbound_amount
        FROM suppliers s
        LEFT JOIN inbound_orders o ON o.supplier_id = s.id
        LEFT JOIN inbound_items i ON i.inbound_order_id = o.id
        GROUP BY s.id, s.name
        ORDER BY inbound_amount DESC
    """,
    "low_stock": """
        SELECT sku, product_name, category, supplier_name, stock_qty, warning_stock, stock_status
        FROM v_inventory_detail
        WHERE stock_qty <= warning_stock
        ORDER BY stock_qty ASC
    """,
    "daily_flow": """
        SELECT day, COALESCE(SUM(in_qty), 0) AS inbound_qty, COALESCE(SUM(out_qty), 0) AS outbound_qty
        FROM (
            SELECT order_date AS day, SUM(quantity) AS in_qty, 0 AS out_qty
            FROM inbound_orders o JOIN inbound_items i ON i.inbound_order_id = o.id
            GROUP BY order_date
            UNION ALL
            SELECT order_date AS day, 0 AS in_qty, SUM(quantity) AS out_qty
            FROM outbound_orders o JOIN outbound_items i ON i.outbound_order_id = o.id
            GROUP BY order_date
        ) AS flow_data
        GROUP BY day
        ORDER BY day DESC
        LIMIT 20
    """,
    "top_products": """
        SELECT
            p.sku,
            p.name,
            p.category,
            COALESCE(SUM(oi.quantity), 0) AS outbound_qty,
            ROUND(COALESCE(SUM(oi.quantity * oi.unit_price), 0), 2) AS outbound_amount,
            RANK() OVER (ORDER BY COALESCE(SUM(oi.quantity), 0) DESC) AS sales_rank
        FROM products p
        LEFT JOIN outbound_items oi ON oi.product_id = p.id
        GROUP BY p.id, p.sku, p.name, p.category
        ORDER BY outbound_qty DESC
        LIMIT 10
    """,
    "category_amount": """
        SELECT
            category,
            COUNT(*) AS product_count,
            COALESCE(SUM(stock_qty), 0) AS stock_qty,
            ROUND(COALESCE(SUM(stock_amount), 0), 2) AS stock_amount
        FROM v_inventory_detail
        GROUP BY category
        ORDER BY stock_amount DESC
    """,
}


@bp.get("/api/queries/<query_name>")
@permission_required("view_queries")
def complex_query(query_name: str):
    return jsonify(query_all(REPORT_SQL.get(query_name, REPORT_SQL["supplier_amount"])))
