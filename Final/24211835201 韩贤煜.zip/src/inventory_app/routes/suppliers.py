from __future__ import annotations

from flask import Blueprint, jsonify, request

from ..auth import permission_required
from ..db import get_db, query_all


bp = Blueprint("suppliers", __name__)


@bp.get("/api/suppliers")
@permission_required("view_suppliers")
def suppliers():
    keyword = request.args.get("keyword", "").strip()
    rows = query_all(
        """
        SELECT s.*, COUNT(p.id) AS product_count
        FROM suppliers s
        LEFT JOIN products p ON p.supplier_id = s.id
        WHERE ? = '' OR s.name LIKE ? OR s.contact LIKE ? OR s.phone LIKE ?
        GROUP BY s.id, s.name, s.contact, s.phone, s.address, s.created_at
        ORDER BY s.id DESC
        """,
        (keyword, f"%{keyword}%", f"%{keyword}%", f"%{keyword}%"),
    )
    return jsonify(rows)


@bp.post("/api/suppliers")
@permission_required("manage_suppliers")
def create_supplier():
    data = request.get_json(force=True)
    name = data["name"].strip()
    with get_db() as conn:
        exists = conn.execute("SELECT 1 FROM suppliers WHERE name = ?", (name,)).fetchone()
        if exists:
            return jsonify({"message": f"供应商名称“{name}”已存在，请换一个名称"}), 400

        conn.execute(
            "INSERT INTO suppliers(name, contact, phone, address) VALUES (?, ?, ?, ?)",
            (name, data["contact"].strip(), data["phone"].strip(), data.get("address", "").strip()),
        )
    return jsonify({"message": "供应商添加成功"})


@bp.put("/api/suppliers/<int:supplier_id>")
@permission_required("manage_suppliers")
def update_supplier(supplier_id: int):
    data = request.get_json(force=True)
    name = data["name"].strip()
    with get_db() as conn:
        supplier = conn.execute("SELECT 1 FROM suppliers WHERE id = ?", (supplier_id,)).fetchone()
        if supplier is None:
            return jsonify({"message": "供应商不存在或已被删除"}), 404

        exists = conn.execute(
            "SELECT 1 FROM suppliers WHERE name = ? AND id <> ?",
            (name, supplier_id),
        ).fetchone()
        if exists:
            return jsonify({"message": f"供应商名称“{name}”已被其他供应商使用，请换一个名称"}), 400

        conn.execute(
            """
            UPDATE suppliers
            SET name = ?, contact = ?, phone = ?, address = ?
            WHERE id = ?
            """,
            (
                name,
                data["contact"].strip(),
                data["phone"].strip(),
                data.get("address", "").strip(),
                supplier_id,
            ),
        )
    return jsonify({"message": "供应商更新成功"})


@bp.delete("/api/suppliers/<int:supplier_id>")
@permission_required("manage_suppliers")
def delete_supplier(supplier_id: int):
    with get_db() as conn:
        conn.execute("DELETE FROM suppliers WHERE id = ?", (supplier_id,))
    return jsonify({"message": "供应商删除成功"})
