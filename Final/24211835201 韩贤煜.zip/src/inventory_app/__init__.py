from __future__ import annotations

import os

from flask import Flask, jsonify

from .config import BASE_DIR, load_env_file
from .db import DatabaseIntegrityError
from .routes import register_blueprints


def create_app() -> Flask:
    load_env_file()

    app = Flask(
        __name__,
        template_folder=str(BASE_DIR / "templates"),
        static_folder=str(BASE_DIR / "static"),
    )
    app.config["JSON_AS_ASCII"] = False
    app.secret_key = os.getenv("SECRET_KEY", "inventory-coursework-dev-key")

    register_blueprints(app)

    @app.errorhandler(DatabaseIntegrityError)
    def handle_integrity_error(error):
        return jsonify({"message": f"数据约束错误：{error.args[-1] if error.args else error}"}), 400

    return app
