from __future__ import annotations

import random
from datetime import date, timedelta
from typing import Any, Iterable

import pymysql
from pymysql.cursors import DictCursor
from werkzeug.security import generate_password_hash

from .config import mysql_config, mysql_database


DatabaseError = pymysql.MySQLError
DatabaseIntegrityError = pymysql.err.IntegrityError


class Row(dict):
    def __getitem__(self, key):
        if isinstance(key, int):
            return list(self.values())[key]
        return super().__getitem__(key)


class CursorAdapter:
    def __init__(self, cursor):
        self.cursor = cursor

    @property
    def lastrowid(self) -> int:
        return self.cursor.lastrowid

    def fetchone(self) -> Row | None:
        row = self.cursor.fetchone()
        return Row(row) if row else None

    def fetchall(self) -> list[Row]:
        return [Row(row) for row in self.cursor.fetchall()]


class ConnectionAdapter:
    def __init__(self, conn):
        self.conn = conn

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, traceback):
        if exc_type is None:
            self.conn.commit()
        else:
            self.conn.rollback()
        self.conn.close()

    def execute(self, sql: str, args: Iterable[Any] | None = None) -> CursorAdapter:
        cursor = self.conn.cursor()
        if args:
            cursor.execute(_mysql_placeholders(sql), tuple(args))
        else:
            cursor.execute(_mysql_placeholders(sql))
        return CursorAdapter(cursor)

    def executemany(self, sql: str, args: Iterable[Iterable[Any]]) -> CursorAdapter:
        cursor = self.conn.cursor()
        cursor.executemany(_mysql_placeholders(sql), list(args))
        return CursorAdapter(cursor)


def _mysql_placeholders(sql: str) -> str:
    return sql.replace("?", "%s")


def _raw_connect(database: str | None = None):
    return pymysql.connect(cursorclass=DictCursor, **mysql_config(database))


def ensure_database() -> None:
    db_name = mysql_database()
    config = mysql_config(database=None)
    config.pop("database", None)
    with pymysql.connect(cursorclass=DictCursor, **config) as conn:
        with conn.cursor() as cursor:
            cursor.execute(
                f"CREATE DATABASE IF NOT EXISTS `{db_name}` "
                "DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
            )
        conn.commit()


def get_db() -> ConnectionAdapter:
    ensure_database()
    return ConnectionAdapter(_raw_connect())


def query_all(sql: str, args: tuple = ()) -> list[dict]:
    with get_db() as conn:
        rows = conn.execute(sql, args).fetchall()
    return [dict(row) for row in rows]


def query_one(sql: str, args: tuple = ()) -> dict | None:
    with get_db() as conn:
        row = conn.execute(sql, args).fetchone()
    return dict(row) if row else None


def init_db(force: bool = False) -> None:
    ensure_database()
    with get_db() as conn:
        if force:
            reset_schema(conn)
        create_schema(conn)

        has_data = conn.execute("SELECT COUNT(*) AS total FROM products").fetchone()["total"] > 0
        if not has_data:
            seed_data(conn)
        ensure_default_users(conn)


def reset_schema(conn: ConnectionAdapter) -> None:
    conn.execute("SET FOREIGN_KEY_CHECKS = 0")
    for trigger in ("trg_product_inventory", "trg_inbound_stock", "trg_outbound_stock", "trg_outbound_stock_update"):
        conn.execute(f"DROP TRIGGER IF EXISTS {trigger}")
    conn.execute("DROP VIEW IF EXISTS v_inventory_detail")
    for table in (
        "outbound_items",
        "outbound_orders",
        "inbound_items",
        "inbound_orders",
        "inventory",
        "products",
        "suppliers",
        "users",
    ):
        conn.execute(f"DROP TABLE IF EXISTS {table}")
    conn.execute("SET FOREIGN_KEY_CHECKS = 1")


def create_schema(conn: ConnectionAdapter) -> None:
    statements = [
        """
        CREATE TABLE IF NOT EXISTS suppliers (
            id INT PRIMARY KEY AUTO_INCREMENT,
            name VARCHAR(100) NOT NULL UNIQUE,
            contact VARCHAR(50) NOT NULL,
            phone VARCHAR(30) NOT NULL,
            address VARCHAR(255),
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        """
        CREATE TABLE IF NOT EXISTS products (
            id INT PRIMARY KEY AUTO_INCREMENT,
            sku VARCHAR(50) NOT NULL UNIQUE,
            name VARCHAR(100) NOT NULL,
            category VARCHAR(50) NOT NULL,
            unit VARCHAR(20) NOT NULL DEFAULT '件',
            price DECIMAL(10,2) NOT NULL CHECK (price >= 0),
            warning_stock INT NOT NULL DEFAULT 20 CHECK (warning_stock >= 0),
            supplier_id INT,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_products_supplier
                FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        """
        CREATE TABLE IF NOT EXISTS inbound_orders (
            id INT PRIMARY KEY AUTO_INCREMENT,
            order_no VARCHAR(50) NOT NULL UNIQUE,
            supplier_id INT NOT NULL,
            handler VARCHAR(50) NOT NULL,
            order_date DATE NOT NULL,
            remark TEXT,
            CONSTRAINT fk_inbound_orders_supplier
                FOREIGN KEY (supplier_id) REFERENCES suppliers(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        """
        CREATE TABLE IF NOT EXISTS inbound_items (
            id INT PRIMARY KEY AUTO_INCREMENT,
            inbound_order_id INT NOT NULL,
            product_id INT NOT NULL,
            quantity INT NOT NULL CHECK (quantity > 0),
            unit_price DECIMAL(10,2) NOT NULL CHECK (unit_price >= 0),
            CONSTRAINT fk_inbound_items_order
                FOREIGN KEY (inbound_order_id) REFERENCES inbound_orders(id) ON DELETE CASCADE,
            CONSTRAINT fk_inbound_items_product
                FOREIGN KEY (product_id) REFERENCES products(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        """
        CREATE TABLE IF NOT EXISTS outbound_orders (
            id INT PRIMARY KEY AUTO_INCREMENT,
            order_no VARCHAR(50) NOT NULL UNIQUE,
            customer VARCHAR(100) NOT NULL,
            handler VARCHAR(50) NOT NULL,
            order_date DATE NOT NULL,
            remark TEXT
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        """
        CREATE TABLE IF NOT EXISTS outbound_items (
            id INT PRIMARY KEY AUTO_INCREMENT,
            outbound_order_id INT NOT NULL,
            product_id INT NOT NULL,
            quantity INT NOT NULL CHECK (quantity > 0),
            unit_price DECIMAL(10,2) NOT NULL CHECK (unit_price >= 0),
            CONSTRAINT fk_outbound_items_order
                FOREIGN KEY (outbound_order_id) REFERENCES outbound_orders(id) ON DELETE CASCADE,
            CONSTRAINT fk_outbound_items_product
                FOREIGN KEY (product_id) REFERENCES products(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        """
        CREATE TABLE IF NOT EXISTS inventory (
            product_id INT PRIMARY KEY,
            stock_qty INT NOT NULL DEFAULT 0 CHECK (stock_qty >= 0),
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_inventory_product
                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        """
        CREATE TABLE IF NOT EXISTS users (
            id INT PRIMARY KEY AUTO_INCREMENT,
            username VARCHAR(50) NOT NULL UNIQUE,
            role VARCHAR(20) NOT NULL CHECK (role IN ('管理员', '仓库员', '查询员')),
            password VARCHAR(255) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        """
        CREATE OR REPLACE VIEW v_inventory_detail AS
        SELECT
            p.id AS product_id,
            p.sku,
            p.name AS product_name,
            p.category,
            p.unit,
            p.price,
            p.warning_stock,
            COALESCE(s.name, '未指定') AS supplier_name,
            COALESCE(i.stock_qty, 0) AS stock_qty,
            COALESCE(i.stock_qty, 0) * p.price AS stock_amount,
            CASE
                WHEN COALESCE(i.stock_qty, 0) <= p.warning_stock THEN '库存预警'
                ELSE '正常'
            END AS stock_status
        FROM products p
        LEFT JOIN suppliers s ON s.id = p.supplier_id
        LEFT JOIN inventory i ON i.product_id = p.id
        """,
        """
        CREATE TRIGGER trg_product_inventory
        AFTER INSERT ON products
        FOR EACH ROW
        BEGIN
            INSERT IGNORE INTO inventory(product_id, stock_qty, updated_at)
            VALUES (NEW.id, 0, CURRENT_TIMESTAMP);
        END
        """,
        """
        CREATE TRIGGER trg_inbound_stock
        AFTER INSERT ON inbound_items
        FOR EACH ROW
        BEGIN
            UPDATE inventory
            SET stock_qty = stock_qty + NEW.quantity,
                updated_at = CURRENT_TIMESTAMP
            WHERE product_id = NEW.product_id;
        END
        """,
        """
        CREATE TRIGGER trg_outbound_stock
        BEFORE INSERT ON outbound_items
        FOR EACH ROW
        BEGIN
            IF (SELECT COALESCE(stock_qty, 0) FROM inventory WHERE product_id = NEW.product_id) < NEW.quantity THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '库存不足，无法出库';
            END IF;
        END
        """,
        """
        CREATE TRIGGER trg_outbound_stock_update
        AFTER INSERT ON outbound_items
        FOR EACH ROW
        BEGIN
            UPDATE inventory
            SET stock_qty = stock_qty - NEW.quantity,
                updated_at = CURRENT_TIMESTAMP
            WHERE product_id = NEW.product_id;
        END
        """,
    ]

    for statement in statements[:8]:
        conn.execute(statement)
    create_index_if_missing(conn, "products", "idx_products_supplier", "supplier_id")
    create_index_if_missing(conn, "inbound_orders", "idx_inbound_date", "order_date")
    create_index_if_missing(conn, "outbound_orders", "idx_outbound_date", "order_date")
    create_index_if_missing(conn, "inbound_items", "idx_inbound_product", "product_id")
    create_index_if_missing(conn, "outbound_items", "idx_outbound_product", "product_id")
    conn.execute(statements[8])
    for trigger in ("trg_product_inventory", "trg_inbound_stock", "trg_outbound_stock", "trg_outbound_stock_update"):
        conn.execute(f"DROP TRIGGER IF EXISTS {trigger}")
    for statement in statements[9:]:
        conn.execute(statement)


def create_index_if_missing(conn: ConnectionAdapter, table: str, index_name: str, columns: str) -> None:
    exists = conn.execute(
        """
        SELECT COUNT(*) AS total
        FROM INFORMATION_SCHEMA.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?
        """,
        (table, index_name),
    ).fetchone()["total"]
    if not exists:
        conn.execute(f"CREATE INDEX {index_name} ON {table}({columns})")


def seed_data(conn: ConnectionAdapter) -> None:
    suppliers = [
        ("晨光文具批发有限公司", "张经理", "13800010001", "广州市天河区"),
        ("华南食品供应链", "李主管", "13800010002", "深圳市南山区"),
        ("宏远日化贸易", "王经理", "13800010003", "佛山市禅城区"),
        ("优品数码配件", "赵主管", "13800010004", "东莞市松山湖"),
        ("绿源生鲜配送", "陈经理", "13800010005", "广州市番禺区"),
    ]
    conn.executemany(
        "INSERT INTO suppliers(name, contact, phone, address) VALUES (?, ?, ?, ?)",
        suppliers,
    )

    categories = ["文具", "食品", "日化", "数码", "生鲜"]
    products = []
    for idx in range(1, 31):
        supplier_id = (idx - 1) % len(suppliers) + 1
        category = categories[(idx - 1) % len(categories)]
        products.append(
            (
                f"SP{idx:04d}",
                f"{category}商品{idx:02d}",
                category,
                "件" if category != "生鲜" else "kg",
                round(random.uniform(6, 180), 2),
                random.randint(10, 35),
                supplier_id,
            )
        )
    conn.executemany(
        """
        INSERT INTO products(sku, name, category, unit, price, warning_stock, supplier_id)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        products,
    )

    conn.executemany(
        "INSERT INTO users(username, role, password) VALUES (?, ?, ?)",
        [
            ("admin", "管理员", generate_password_hash("123456")),
            ("stock01", "仓库员", generate_password_hash("123456")),
            ("query01", "查询员", generate_password_hash("123456")),
        ],
    )

    handlers = ["经手人", "仓库员A", "仓库员B"]
    start = date.today() - timedelta(days=45)
    for order_idx in range(1, 71):
        order_date = start + timedelta(days=random.randint(0, 45))
        supplier_id = random.randint(1, len(suppliers))
        cursor = conn.execute(
            """
            INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                f"RK{order_date:%Y%m%d}{order_idx:03d}",
                supplier_id,
                random.choice(handlers),
                order_date.isoformat(),
                "期初入库" if order_idx <= 10 else "采购入库",
            ),
        )
        order_id = cursor.lastrowid
        for product_id in random.sample(range(1, 31), random.randint(1, 4)):
            price = conn.execute("SELECT price FROM products WHERE id = ?", (product_id,)).fetchone()[0]
            conn.execute(
                """
                INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
                VALUES (?, ?, ?, ?)
                """,
                (order_id, product_id, random.randint(20, 120), price),
            )

    customers = ["校园超市", "社区便利店", "办公客户", "线上订单", "团购客户"]
    for order_idx in range(1, 51):
        order_date = start + timedelta(days=random.randint(10, 45))
        cursor = conn.execute(
            """
            INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                f"CK{order_date:%Y%m%d}{order_idx:03d}",
                random.choice(customers),
                random.choice(handlers),
                order_date.isoformat(),
                "销售出库",
            ),
        )
        order_id = cursor.lastrowid
        for product_id in random.sample(range(1, 31), random.randint(1, 3)):
            stock = conn.execute(
                "SELECT stock_qty FROM inventory WHERE product_id = ?",
                (product_id,),
            ).fetchone()[0]
            if stock <= 5:
                continue
            price = conn.execute("SELECT price FROM products WHERE id = ?", (product_id,)).fetchone()[0]
            conn.execute(
                """
                INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
                VALUES (?, ?, ?, ?)
                """,
                (order_id, product_id, random.randint(1, min(30, stock)), price),
            )


def ensure_default_users(conn: ConnectionAdapter) -> None:
    defaults = [
        ("admin", "管理员", "123456"),
        ("stock01", "仓库员", "123456"),
        ("query01", "查询员", "123456"),
    ]
    for username, role, password in defaults:
        conn.execute(
            "INSERT IGNORE INTO users(username, role, password) VALUES (?, ?, ?)",
            (username, role, generate_password_hash(password)),
        )
