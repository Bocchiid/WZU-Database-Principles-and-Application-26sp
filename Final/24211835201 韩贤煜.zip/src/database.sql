-- ============================================================
-- 库存管理系统 - 数据库建库脚本
-- 数据库: inventory_system
-- 说明: 执行本脚本可完整创建数据库、表结构、视图、触发器和种子数据
-- ============================================================

CREATE DATABASE IF NOT EXISTS `inventory_system`
    DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `inventory_system`;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS outbound_items;
DROP TABLE IF EXISTS outbound_orders;
DROP TABLE IF EXISTS inbound_items;
DROP TABLE IF EXISTS inbound_orders;
DROP TABLE IF EXISTS inventory;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS suppliers;
DROP TABLE IF EXISTS users;

-- 1. 供应商表
CREATE TABLE suppliers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL UNIQUE,
    contact VARCHAR(50) NOT NULL,
    phone VARCHAR(30) NOT NULL,
    address VARCHAR(255),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. 商品表
CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    sku VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    unit VARCHAR(20) NOT NULL DEFAULT '件',
    price DECIMAL(10,2) NOT NULL CHECK (price >= 0),
    warning_stock INT NOT NULL DEFAULT 20 CHECK (warning_stock >= 0),
    supplier_id INT,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_products_supplier
        FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. 入库单表
CREATE TABLE inbound_orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_no VARCHAR(50) NOT NULL UNIQUE,
    supplier_id INT NOT NULL,
    handler VARCHAR(50) NOT NULL,
    order_date DATE NOT NULL,
    remark TEXT,
    CONSTRAINT fk_inbound_orders_supplier
        FOREIGN KEY (supplier_id) REFERENCES suppliers(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. 入库明细表
CREATE TABLE inbound_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    inbound_order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    unit_price DECIMAL(10,2) NOT NULL CHECK (unit_price >= 0),
    CONSTRAINT fk_inbound_items_order
        FOREIGN KEY (inbound_order_id) REFERENCES inbound_orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_inbound_items_product
        FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. 出库单表
CREATE TABLE outbound_orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_no VARCHAR(50) NOT NULL UNIQUE,
    customer VARCHAR(100) NOT NULL,
    handler VARCHAR(50) NOT NULL,
    order_date DATE NOT NULL,
    remark TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. 出库明细表
CREATE TABLE outbound_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    outbound_order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    unit_price DECIMAL(10,2) NOT NULL CHECK (unit_price >= 0),
    CONSTRAINT fk_outbound_items_order
        FOREIGN KEY (outbound_order_id) REFERENCES outbound_orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_outbound_items_product
        FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. 库存表
CREATE TABLE inventory (
    product_id INT PRIMARY KEY,
    stock_qty INT NOT NULL DEFAULT 0 CHECK (stock_qty >= 0),
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_inventory_product
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. 用户表
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    role VARCHAR(20) NOT NULL CHECK (role IN ('管理员', '仓库员', '查询员')),
    password VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 创建索引
CREATE INDEX idx_products_supplier ON products(supplier_id);
CREATE INDEX idx_inbound_date ON inbound_orders(order_date);
CREATE INDEX idx_outbound_date ON outbound_orders(order_date);
CREATE INDEX idx_inbound_product ON inbound_items(product_id);
CREATE INDEX idx_outbound_product ON outbound_items(product_id);

-- 9. 库存明细视图
CREATE OR REPLACE VIEW v_inventory_detail AS
SELECT
    p.id AS product_id,
    p.sku,
    p.name AS product_name,
    p.category,
    p.unit,
    p.price,
    p.warning_stock,
    COALESCE(s.name, '未指定') AS supplier_name,
    COALESCE(i.stock_qty, 0) AS stock_qty,
    COALESCE(i.stock_qty, 0) * p.price AS stock_amount,
    CASE
        WHEN COALESCE(i.stock_qty, 0) <= p.warning_stock THEN '库存预警'
        ELSE '正常'
    END AS stock_status
FROM products p
LEFT JOIN suppliers s ON s.id = p.supplier_id
LEFT JOIN inventory i ON i.product_id = p.id;

-- 10. 触发器：新增商品时自动创建库存记录
DROP TRIGGER IF EXISTS trg_product_inventory;
DELIMITER $$
CREATE TRIGGER trg_product_inventory
AFTER INSERT ON products
FOR EACH ROW
BEGIN
    INSERT IGNORE INTO inventory(product_id, stock_qty, updated_at)
    VALUES (NEW.id, 0, CURRENT_TIMESTAMP);
END$$
DELIMITER ;

-- 11. 触发器：入库时增加库存
DROP TRIGGER IF EXISTS trg_inbound_stock;
DELIMITER $$
CREATE TRIGGER trg_inbound_stock
AFTER INSERT ON inbound_items
FOR EACH ROW
BEGIN
    UPDATE inventory
    SET stock_qty = stock_qty + NEW.quantity,
        updated_at = CURRENT_TIMESTAMP
    WHERE product_id = NEW.product_id;
END$$
DELIMITER ;

-- 12. 触发器：出库前检查库存是否充足
DROP TRIGGER IF EXISTS trg_outbound_stock;
DELIMITER $$
CREATE TRIGGER trg_outbound_stock
BEFORE INSERT ON outbound_items
FOR EACH ROW
BEGIN
    IF (SELECT COALESCE(stock_qty, 0) FROM inventory WHERE product_id = NEW.product_id) < NEW.quantity THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '库存不足，无法出库';
    END IF;
END$$
DELIMITER ;

-- 13. 触发器：出库后扣减库存
DROP TRIGGER IF EXISTS trg_outbound_stock_update;
DELIMITER $$
CREATE TRIGGER trg_outbound_stock_update
AFTER INSERT ON outbound_items
FOR EACH ROW
BEGIN
    UPDATE inventory
    SET stock_qty = stock_qty - NEW.quantity,
        updated_at = CURRENT_TIMESTAMP
    WHERE product_id = NEW.product_id;
END$$
DELIMITER ;

SET FOREIGN_KEY_CHECKS = 1;

-- 供应商种子数据
INSERT INTO suppliers(name, contact, phone, address) VALUES
('晨光文具批发有限公司', '张经理', '13800010001', '广州市天河区'),
('华南食品供应链', '李主管', '13800010002', '深圳市南山区'),
('宏远日化贸易', '王经理', '13800010003', '佛山市禅城区'),
('优品数码配件', '赵主管', '13800010004', '东莞市松山湖'),
('绿源生鲜配送', '陈经理', '13800010005', '广州市番禺区');

-- 商品种子数据 (30条)
INSERT INTO products(sku, name, category, unit, price, warning_stock, supplier_id) VALUES
('SP0001', '文具01', '文具', '件', 117.26, 10, 1),
('SP0002', '食品02', '食品', '件', 135.03, 17, 2),
('SP0003', '日化03', '日化', '件', 44.84, 33, 3),
('SP0004', '数码04', '数码', '件', 23.83, 33, 4),
('SP0005', '生鲜05', '生鲜', 'kg', 161.24, 12, 5),
('SP0006', '文具06', '文具', '件', 108.75, 11, 1),
('SP0007', '食品07', '食品', '件', 11.18, 16, 2),
('SP0008', '日化08', '日化', '件', 46.48, 29, 3),
('SP0009', '数码09', '数码', '件', 10.62, 16, 4),
('SP0010', '生鲜10', '生鲜', 'kg', 130.59, 32, 5),
('SP0011', '文具11', '文具', '件', 100.82, 17, 1),
('SP0012', '食品12', '食品', '件', 84.16, 18, 2),
('SP0013', '日化13', '日化', '件', 146.84, 10, 3),
('SP0014', '数码14', '数码', '件', 138.03, 15, 4),
('SP0015', '生鲜15', '生鲜', 'kg', 127.48, 20, 5),
('SP0016', '文具16', '文具', '件', 54.35, 16, 1),
('SP0017', '食品17', '食品', '件', 172.56, 20, 2),
('SP0018', '日化18', '日化', '件', 23.78, 22, 3),
('SP0019', '数码19', '数码', '件', 22.83, 21, 4),
('SP0020', '生鲜20', '生鲜', 'kg', 111.05, 35, 5),
('SP0021', '文具21', '文具', '件', 13.56, 24, 1),
('SP0022', '食品22', '食品', '件', 99.30, 22, 2),
('SP0023', '日化23', '日化', '件', 19.71, 19, 3),
('SP0024', '数码24', '数码', '件', 150.32, 29, 4),
('SP0025', '生鲜25', '生鲜', 'kg', 160.07, 21, 5),
('SP0026', '文具26', '文具', '件', 106.46, 32, 1),
('SP0027', '食品27', '食品', '件', 18.10, 31, 2),
('SP0028', '日化28', '日化', '件', 45.65, 19, 3),
('SP0029', '数码29', '数码', '件', 177.43, 17, 4),
('SP0030', '生鲜30', '生鲜', 'kg', 156.77, 22, 5);

-- 用户种子数据 (密码均为 123456)
INSERT INTO users(username, role, password) VALUES
('admin', '管理员', 'scrypt:32768:8:1$QUdkDhN7dWy8PPCS$3f6a04df02b77227393f1327c2c1354def4ab9ca60479edbc74b5cc7a253542c5b53077ba1c5126275f88b2735ca00c4dc84d8317e2b88431ab75802d2ff6852'),
('stock01', '仓库员', 'scrypt:32768:8:1$iDBEI7sqW2DgGkAJ$151f1bc2a7fcfb53d7b08841a317f7283e5cc2d89c7bc6218835b88bbafbfe52eb98b2ed3e76fcb58b023775729c300cae67cbb02c0f9368df9f8e9065ecf3d9'),
('query01', '查询员', 'scrypt:32768:8:1$P3m5dqDcmCWST1Ry$fd1282e314362bdcd59a2aa6c35a1fa5f7bab86f2278d7b1b2bbae09bcbffccbbabbac5ead78689d0ae6205d0b7b2e05d1718a65a6278bba67655e8b0e5169e0');

-- 入库单种子数据 (70条)
INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260529001', 4, '仓库员B', '2026-05-29', '期初入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (1, 6, 105, 108.75);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (1, 12, 54, 84.16);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (1, 7, 109, 11.18);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260624002', 1, '仓库员B', '2026-06-24', '期初入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (2, 18, 51, 23.78);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (2, 24, 40, 150.32);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260610003', 4, '仓库员A', '2026-06-10', '期初入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (3, 22, 118, 99.30);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (3, 11, 119, 100.82);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260515004', 2, '经手人', '2026-05-15', '期初入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (4, 13, 47, 146.84);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (4, 9, 92, 10.62);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (4, 3, 111, 44.84);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260601005', 2, '仓库员B', '2026-06-01', '期初入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (5, 13, 78, 146.84);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (5, 29, 38, 177.43);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (5, 30, 53, 156.77);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (5, 21, 37, 13.56);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260527006', 5, '仓库员B', '2026-05-27', '期初入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (6, 24, 94, 150.32);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (6, 19, 71, 22.83);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (6, 14, 66, 138.03);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260526007', 2, '仓库员B', '2026-05-26', '期初入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (7, 3, 34, 44.84);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (7, 25, 39, 160.07);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (7, 2, 100, 135.03);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (7, 28, 40, 45.65);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260624008', 4, '仓库员B', '2026-06-24', '期初入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (8, 13, 68, 146.84);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260619009', 4, '仓库员B', '2026-06-19', '期初入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (9, 18, 107, 23.78);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (9, 28, 112, 45.65);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (9, 1, 34, 117.26);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260624010', 5, '仓库员A', '2026-06-24', '期初入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (10, 4, 40, 23.83);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (10, 10, 78, 130.59);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (10, 14, 20, 138.03);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260528011', 5, '经手人', '2026-05-28', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (11, 28, 100, 45.65);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260531012', 5, '仓库员B', '2026-05-31', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (12, 5, 117, 161.24);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (12, 12, 40, 84.16);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260615013', 5, '经手人', '2026-06-15', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (13, 16, 66, 54.35);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (13, 1, 59, 117.26);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (13, 4, 50, 23.83);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260515014', 2, '仓库员B', '2026-05-15', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (14, 3, 113, 44.84);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260612015', 1, '仓库员B', '2026-06-12', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (15, 5, 80, 161.24);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (15, 22, 90, 99.30);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260522016', 3, '仓库员B', '2026-05-22', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (16, 7, 113, 11.18);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (16, 30, 108, 156.77);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (16, 18, 45, 23.78);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (16, 25, 111, 160.07);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260531017', 4, '仓库员B', '2026-05-31', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (17, 15, 77, 127.48);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (17, 29, 35, 177.43);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (17, 17, 51, 172.56);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260526018', 1, '仓库员A', '2026-05-26', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (18, 19, 90, 22.83);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260526019', 5, '经手人', '2026-05-26', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (19, 3, 110, 44.84);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260621020', 1, '经手人', '2026-06-21', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (20, 29, 24, 177.43);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260602021', 1, '仓库员B', '2026-06-02', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (21, 9, 82, 10.62);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (21, 22, 47, 99.30);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260615022', 2, '仓库员B', '2026-06-15', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (22, 8, 44, 46.48);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (22, 26, 32, 106.46);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (22, 16, 32, 54.35);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (22, 14, 104, 138.03);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260608023', 3, '仓库员A', '2026-06-08', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (23, 15, 106, 127.48);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (23, 28, 103, 45.65);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (23, 24, 102, 150.32);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (23, 2, 32, 135.03);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260515024', 4, '仓库员B', '2026-05-15', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (24, 26, 51, 106.46);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (24, 28, 44, 45.65);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (24, 4, 44, 23.83);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260615025', 4, '经手人', '2026-06-15', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (25, 6, 29, 108.75);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (25, 9, 76, 10.62);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (25, 15, 90, 127.48);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (25, 8, 32, 46.48);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260515026', 5, '经手人', '2026-05-15', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (26, 30, 116, 156.77);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260527027', 2, '仓库员A', '2026-05-27', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (27, 16, 27, 54.35);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (27, 7, 41, 11.18);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (27, 28, 68, 45.65);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (27, 13, 20, 146.84);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260605028', 3, '仓库员A', '2026-06-05', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (28, 14, 120, 138.03);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (28, 23, 91, 19.71);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (28, 24, 104, 150.32);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260626029', 4, '经手人', '2026-06-26', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (29, 10, 27, 130.59);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (29, 7, 94, 11.18);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260615030', 1, '仓库员B', '2026-06-15', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (30, 2, 84, 135.03);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (30, 19, 87, 22.83);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (30, 16, 40, 54.35);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260515031', 5, '经手人', '2026-05-15', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (31, 3, 28, 44.84);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (31, 20, 106, 111.05);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260527032', 4, '经手人', '2026-05-27', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (32, 19, 25, 22.83);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (32, 20, 99, 111.05);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260517033', 4, '仓库员B', '2026-05-17', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (33, 30, 105, 156.77);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (33, 9, 111, 10.62);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (33, 7, 60, 11.18);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260527034', 3, '仓库员A', '2026-05-27', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (34, 22, 58, 99.30);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (34, 21, 78, 13.56);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260601035', 1, '经手人', '2026-06-01', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (35, 20, 88, 111.05);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (35, 19, 47, 22.83);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (35, 4, 84, 23.83);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (35, 3, 53, 44.84);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260520036', 3, '经手人', '2026-05-20', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (36, 12, 40, 84.16);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (36, 10, 76, 130.59);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260615037', 3, '仓库员B', '2026-06-15', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (37, 22, 90, 99.30);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260531038', 1, '经手人', '2026-05-31', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (38, 4, 90, 23.83);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (38, 29, 39, 177.43);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (38, 24, 54, 150.32);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260530039', 5, '经手人', '2026-05-30', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (39, 7, 53, 11.18);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (39, 22, 84, 99.30);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (39, 21, 82, 13.56);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260528040', 1, '经手人', '2026-05-28', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (40, 27, 62, 18.10);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (40, 9, 118, 10.62);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (40, 2, 36, 135.03);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (40, 1, 101, 117.26);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260528041', 2, '仓库员B', '2026-05-28', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (41, 18, 34, 23.78);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (41, 23, 29, 19.71);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (41, 14, 108, 138.03);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (41, 1, 39, 117.26);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260615042', 1, '仓库员A', '2026-06-15', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (42, 14, 25, 138.03);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (42, 5, 59, 161.24);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260604043', 1, '仓库员A', '2026-06-04', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (43, 22, 105, 99.30);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (43, 8, 33, 46.48);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260603044', 5, '仓库员A', '2026-06-03', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (44, 30, 40, 156.77);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (44, 8, 42, 46.48);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260607045', 1, '经手人', '2026-06-07', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (45, 26, 105, 106.46);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (45, 30, 114, 156.77);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (45, 14, 51, 138.03);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260529046', 2, '仓库员B', '2026-05-29', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (46, 13, 24, 146.84);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260611047', 2, '经手人', '2026-06-11', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (47, 12, 49, 84.16);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (47, 10, 48, 130.59);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (47, 27, 23, 18.10);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (47, 26, 104, 106.46);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260524048', 4, '仓库员A', '2026-05-24', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (48, 28, 55, 45.65);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (48, 3, 64, 44.84);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (48, 25, 102, 160.07);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260613049', 4, '仓库员B', '2026-06-13', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (49, 1, 53, 117.26);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (49, 4, 42, 23.83);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (49, 29, 94, 177.43);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260528050', 1, '经手人', '2026-05-28', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (50, 12, 75, 84.16);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (50, 24, 97, 150.32);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (50, 26, 85, 106.46);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (50, 11, 34, 100.82);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260605051', 5, '经手人', '2026-06-05', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (51, 2, 20, 135.03);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (51, 23, 86, 19.71);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (51, 14, 88, 138.03);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260624052', 2, '仓库员A', '2026-06-24', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (52, 3, 99, 44.84);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (52, 22, 60, 99.30);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (52, 30, 104, 156.77);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (52, 11, 35, 100.82);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260531053', 5, '仓库员A', '2026-05-31', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (53, 11, 90, 100.82);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (53, 13, 36, 146.84);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (53, 23, 44, 19.71);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (53, 10, 73, 130.59);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260623054', 4, '仓库员B', '2026-06-23', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (54, 20, 58, 111.05);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (54, 19, 71, 22.83);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260616055', 1, '仓库员A', '2026-06-16', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (55, 7, 94, 11.18);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (55, 14, 97, 138.03);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (55, 26, 103, 106.46);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260601056', 4, '仓库员A', '2026-06-01', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (56, 22, 114, 99.30);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (56, 7, 41, 11.18);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (56, 17, 104, 172.56);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (56, 16, 30, 54.35);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260530057', 5, '仓库员B', '2026-05-30', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (57, 3, 50, 44.84);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (57, 27, 106, 18.10);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (57, 25, 59, 160.07);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260526058', 2, '经手人', '2026-05-26', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (58, 2, 51, 135.03);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260611059', 5, '经手人', '2026-06-11', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (59, 14, 44, 138.03);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (59, 29, 111, 177.43);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (59, 21, 109, 13.56);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (59, 19, 69, 22.83);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260612060', 4, '经手人', '2026-06-12', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (60, 21, 20, 13.56);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (60, 23, 116, 19.71);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260518061', 4, '经手人', '2026-05-18', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (61, 26, 86, 106.46);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (61, 23, 79, 19.71);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260515062', 5, '经手人', '2026-05-15', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (62, 15, 37, 127.48);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260610063', 5, '仓库员B', '2026-06-10', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (63, 25, 98, 160.07);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (63, 29, 112, 177.43);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (63, 15, 84, 127.48);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260608064', 5, '仓库员A', '2026-06-08', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (64, 24, 80, 150.32);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (64, 28, 77, 45.65);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260528065', 2, '仓库员B', '2026-05-28', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (65, 25, 100, 160.07);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (65, 17, 50, 172.56);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (65, 16, 55, 54.35);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260609066', 1, '仓库员B', '2026-06-09', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (66, 8, 60, 46.48);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (66, 9, 89, 10.62);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (66, 11, 30, 100.82);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260520067', 2, '经手人', '2026-05-20', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (67, 23, 73, 19.71);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (67, 5, 72, 161.24);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (67, 7, 62, 11.18);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (67, 3, 89, 44.84);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260610068', 4, '经手人', '2026-06-10', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (68, 27, 69, 18.10);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (68, 14, 118, 138.03);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260618069', 1, '仓库员B', '2026-06-18', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (69, 16, 116, 54.35);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (69, 1, 69, 117.26);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (69, 12, 73, 84.16);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (69, 10, 88, 130.59);

INSERT INTO inbound_orders(order_no, supplier_id, handler, order_date, remark)
VALUES ('RK20260615070', 5, '经手人', '2026-06-15', '采购入库');
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (70, 8, 23, 46.48);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (70, 9, 69, 10.62);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (70, 14, 63, 138.03);
INSERT INTO inbound_items(inbound_order_id, product_id, quantity, unit_price)
VALUES (70, 16, 105, 54.35);

-- 出库单种子数据 (50条)
INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260616001', '社区便利店', '仓库员B', '2026-06-16', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (71, 30, 20, 156.77);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (71, 5, 18, 161.24);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260523002', '团购客户', '仓库员A', '2026-05-23', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (72, 22, 21, 99.30);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (72, 1, 14, 117.26);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (72, 3, 5, 44.84);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260620003', '校园超市', '经手人', '2026-06-20', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (73, 13, 7, 146.84);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (73, 11, 15, 100.82);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260611004', '线上订单', '仓库员A', '2026-06-11', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (74, 25, 14, 160.07);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (74, 27, 9, 18.10);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260527005', '校园超市', '仓库员A', '2026-05-27', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (75, 18, 8, 23.78);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (75, 2, 21, 135.03);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (75, 12, 3, 84.16);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260524006', '社区便利店', '经手人', '2026-05-24', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (76, 27, 1, 18.10);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260531007', '社区便利店', '经手人', '2026-05-31', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (77, 22, 19, 99.30);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (77, 4, 7, 23.83);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260620008', '办公客户', '仓库员B', '2026-06-20', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (78, 6, 20, 108.75);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (78, 20, 24, 111.05);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260529009', '办公客户', '经手人', '2026-05-29', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (79, 19, 1, 22.83);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260610010', '线上订单', '仓库员B', '2026-06-10', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (80, 23, 3, 19.71);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (80, 7, 19, 11.18);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260606011', '办公客户', '经手人', '2026-06-06', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (81, 20, 26, 111.05);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (81, 26, 19, 106.46);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (81, 4, 26, 23.83);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260524012', '团购客户', '仓库员A', '2026-05-24', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (82, 22, 3, 99.30);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (82, 12, 17, 84.16);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260612013', '线上订单', '经手人', '2026-06-12', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (83, 4, 12, 23.83);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (83, 14, 21, 138.03);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260620014', '社区便利店', '仓库员B', '2026-06-20', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (84, 6, 17, 108.75);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (84, 24, 21, 150.32);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260608015', '团购客户', '仓库员B', '2026-06-08', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (85, 15, 27, 127.48);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (85, 14, 24, 138.03);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260608016', '社区便利店', '仓库员A', '2026-06-08', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (86, 9, 29, 10.62);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260619017', '线上订单', '经手人', '2026-06-19', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (87, 20, 11, 111.05);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (87, 22, 1, 99.30);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (87, 13, 16, 146.84);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260611018', '线上订单', '经手人', '2026-06-11', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (88, 12, 26, 84.16);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260607019', '办公客户', '仓库员A', '2026-06-07', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (89, 23, 18, 19.71);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (89, 29, 1, 177.43);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (89, 9, 17, 10.62);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260603020', '社区便利店', '经手人', '2026-06-03', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (90, 14, 25, 138.03);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (90, 16, 8, 54.35);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (90, 18, 23, 23.78);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260621021', '线上订单', '仓库员B', '2026-06-21', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (91, 26, 3, 106.46);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (91, 1, 10, 117.26);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260605022', '社区便利店', '仓库员A', '2026-06-05', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (92, 22, 12, 99.30);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (92, 19, 16, 22.83);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260626023', '办公客户', '仓库员B', '2026-06-26', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (93, 24, 11, 150.32);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (93, 18, 12, 23.78);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260620024', '办公客户', '仓库员A', '2026-06-20', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (94, 8, 24, 46.48);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (94, 4, 7, 23.83);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260611025', '团购客户', '经手人', '2026-06-11', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (95, 6, 16, 108.75);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (95, 7, 9, 11.18);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (95, 24, 24, 150.32);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260624026', '办公客户', '仓库员B', '2026-06-24', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (96, 27, 7, 18.10);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260609027', '办公客户', '经手人', '2026-06-09', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (97, 10, 1, 130.59);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260625028', '办公客户', '经手人', '2026-06-25', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (98, 2, 18, 135.03);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260609029', '社区便利店', '仓库员B', '2026-06-09', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (99, 28, 4, 45.65);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (99, 25, 28, 160.07);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (99, 16, 1, 54.35);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260609030', '线上订单', '仓库员A', '2026-06-09', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (100, 11, 2, 100.82);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (100, 6, 9, 108.75);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260621031', '校园超市', '经手人', '2026-06-21', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (101, 16, 19, 54.35);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (101, 3, 21, 44.84);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260525032', '社区便利店', '经手人', '2026-05-25', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (102, 10, 4, 130.59);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (102, 3, 18, 44.84);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (102, 8, 25, 46.48);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260617033', '团购客户', '仓库员B', '2026-06-17', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (103, 8, 13, 46.48);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (103, 25, 15, 160.07);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (103, 17, 30, 172.56);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260619034', '团购客户', '仓库员A', '2026-06-19', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (104, 10, 20, 130.59);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (104, 19, 2, 22.83);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260528035', '社区便利店', '经手人', '2026-05-28', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (105, 22, 6, 99.30);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (105, 3, 8, 44.84);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260602036', '校园超市', '仓库员B', '2026-06-02', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (106, 1, 14, 117.26);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260619037', '团购客户', '仓库员B', '2026-06-19', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (107, 10, 8, 130.59);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (107, 2, 10, 135.03);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260609038', '线上订单', '仓库员B', '2026-06-09', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (108, 22, 8, 99.30);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260607039', '团购客户', '仓库员B', '2026-06-07', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (109, 26, 14, 106.46);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (109, 30, 4, 156.77);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (109, 7, 18, 11.18);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260605040', '社区便利店', '仓库员B', '2026-06-05', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (110, 27, 3, 18.10);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (110, 5, 2, 161.24);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260601041', '团购客户', '仓库员A', '2026-06-01', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (111, 27, 10, 18.10);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (111, 19, 15, 22.83);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (111, 30, 4, 156.77);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260620042', '办公客户', '仓库员B', '2026-06-20', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (112, 13, 18, 146.84);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (112, 9, 16, 10.62);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (112, 17, 15, 172.56);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260527043', '校园超市', '仓库员B', '2026-05-27', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (113, 24, 20, 150.32);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (113, 11, 9, 100.82);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260523044', '社区便利店', '经手人', '2026-05-23', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (114, 27, 19, 18.10);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (114, 28, 1, 45.65);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (114, 19, 25, 22.83);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260608045', '校园超市', '仓库员B', '2026-06-08', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (115, 16, 17, 54.35);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260619046', '社区便利店', '仓库员A', '2026-06-19', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (116, 14, 16, 138.03);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (116, 21, 3, 13.56);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (116, 27, 16, 18.10);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260613047', '办公客户', '仓库员A', '2026-06-13', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (117, 22, 28, 99.30);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (117, 4, 6, 23.83);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260612048', '线上订单', '仓库员A', '2026-06-12', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (118, 22, 27, 99.30);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (118, 13, 25, 146.84);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260626049', '线上订单', '经手人', '2026-06-26', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (119, 11, 9, 100.82);

INSERT INTO outbound_orders(order_no, customer, handler, order_date, remark)
VALUES ('CK20260611050', '线上订单', '经手人', '2026-06-11', '销售出库');
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (120, 27, 28, 18.10);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (120, 1, 18, 117.26);
INSERT INTO outbound_items(outbound_order_id, product_id, quantity, unit_price)
VALUES (120, 22, 15, 99.30);

-- ============================================================
-- 脚本执行完成
-- ============================================================